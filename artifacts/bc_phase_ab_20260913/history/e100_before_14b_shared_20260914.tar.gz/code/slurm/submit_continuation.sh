#!/bin/bash
set -euo pipefail
BC_ROOT=/lustre/home/2501111916/workspace/DOPS-Serve/artifacts/bc_phase_ab_20260913
BC_RUN="$BC_ROOT/fresh_b50_20260914"
BC_CONTINUE="$BC_RUN/continuation_to_e100"
test -s "$BC_CONTINUE/preflight_passed.json"
test ! -e "$BC_CONTINUE/jobs.tsv"
mkdir -p "$BC_CONTINUE/logs"
printf 'route\tjob_id\n' > "$BC_CONTINUE/jobs.tsv"
for BC_ROUTE in qwen_1.8b qwen_7b; do
    BC_JOB=$(sbatch --parsable -A hpc2006191081 -p GPU80G -q high -J "bc100-$BC_ROUTE" -c 16 --gres=gpu:1 -t 12:00:00 -o "$BC_CONTINUE/logs/train_${BC_ROUTE}_%j.out" "$BC_ROOT/code/slurm/run.sh" train --route "$BC_ROUTE" --workers 8 --resume-epoch 50 --epochs 100)
    printf '%s\t%s\n' "$BC_ROUTE" "$BC_JOB" >> "$BC_CONTINUE/jobs.tsv"
done
cat "$BC_CONTINUE/jobs.tsv"
