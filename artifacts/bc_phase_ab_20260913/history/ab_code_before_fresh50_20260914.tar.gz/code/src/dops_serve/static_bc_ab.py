"""Paired Qwen-7B BC continuation from E8; only the loss weights differ."""
import argparse
import csv
import filecmp
import gzip
import json
import math
import multiprocessing
import os
import platform
import random
import shutil
import time
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import torch

from . import static_bc as bc
from .placement_policy import StaticPlacementActor

GROUPS = ("prefill", "startup_decode", "steady_decode")


def phase_group(sample):
    return "prefill" if sample["phase"] == "prefill" else "startup_decode" if sample["token_index"] <= 2 else "steady_decode"


def add_phase_weights(samples):
    counts = Counter((row["case_id"], phase_group(row)) for row in samples)
    for row in samples:
        row["group"] = phase_group(row)
        row["phase_weight"] = 1.0 / (3 * counts[row["case_id"], row["group"]])
    return samples


def restore(checkpoint, device):
    state = torch.load(checkpoint, map_location="cpu", weights_only=False)
    actor = StaticPlacementActor(**state["dimensions"]).to(device)
    actor.load_state_dict(state["actor"])
    optimizer = torch.optim.Adam(actor.parameters(), lr=1e-4)
    optimizer.load_state_dict(state["optimizer"])
    rng = random.Random()
    rng.setstate(state["random_state"])
    torch.set_rng_state(state["torch_rng"])
    if device == "cuda":
        torch.cuda.set_rng_state_all(state["cuda_rng"])
    return actor, optimizer, rng, state["epoch"]


def update_batch(actor, optimizer, rows, device, sample_count, task_count, branch, max_grad_norm):
    optimizer.zero_grad(set_to_none=True)
    losses, _ = actor(*bc.batch_tensors(rows, device))
    key = "task_weight" if branch == "A" else "phase_weight"
    weights = torch.tensor([row[key] for row in rows], device=device)
    loss = (losses * weights).mean() * sample_count / task_count
    loss.backward()
    torch.nn.utils.clip_grad_norm_(actor.parameters(), max_grad_norm)
    optimizer.step()
    return float(loss.detach())


def teacher_metrics(actor, samples, device, batch_size):
    actor.eval()
    tasks = len({row["case_id"] for row in samples})
    totals = Counter()
    with torch.inference_mode():
        for rows in bc.batches(samples, batch_size):
            tensors = bc.batch_tensors(rows, device)
            losses, logits = actor(*tensors)
            correct = ((logits.argmax(-1) == tensors[2]) * tensors[4]).sum(1) / tensors[4].sum(1)
            for row, loss, accuracy in zip(rows, losses.tolist(), correct.tolist()):
                totals["nll"] += loss * row["task_weight"] / tasks
                group_weight = 3 * row["phase_weight"] / tasks
                totals[row["group"] + "_nll"] += loss * group_weight
                totals[row["group"] + "_teacher_forced_match"] += accuracy * group_weight
    totals["phase_balanced_nll"] = sum(totals[group + "_nll"] for group in GROUPS) / 3
    return dict(totals)


def evaluate_case(arguments):
    root, backend, case, checkpoint, branch, epoch = arguments
    torch.set_num_threads(1)
    os.environ["PIM_LATENCY_CACHE_FILE"] = str(root / "runtime" / f"pim_{branch}_{epoch}_{case['case_id']}.json")
    state = torch.load(checkpoint, map_location="cpu", weights_only=False)
    actor = StaticPlacementActor(**state["dimensions"])
    actor.load_state_dict(state["actor"])
    actor = torch.jit.script(actor.eval())
    reference = bc.read(root / "results" / f"{case['case_id']:03d}.json")
    counts = {group: Counter() for group in GROUPS}
    prefill_s = 0.0
    with gzip.open(root / "anchors" / f"{case['case_id']:03d}.jsonl.gz", "rt") as stream:
        def observe(sample):
            nonlocal prefill_s
            teacher = json.loads(next(stream))
            assert teacher["token_index"] == sample["token_index"]
            group = phase_group(sample)
            correct = total = pim_to_npu = 0
            for expected, chosen, learned in zip(teacher["actions"], sample["actions"], teacher["learned"]):
                if learned:
                    total += 1
                    correct += expected == chosen
                    pim_to_npu += expected in (1, 2) and chosen == 0
            counts[group].update(correct=correct, total=total, plans=1, exact=int(correct == total), pim_to_npu=pim_to_npu)
            if sample["token_index"] == 0:
                prefill_s = sample["now_s"]
        with torch.inference_mode():
            result = bc.replay_task(root, backend, case, reference["summary_path"], actor=actor,
                on_plan=observe, name=f"{branch}_e{epoch}_{case['case_id']}")
        assert next(stream, None) is None
    output, elapsed = result["output_tokens"], result["simulated_s"]
    row = dict(case_id=case["case_id"], model=case["model"], batch=case["batch"], prompt=case["prompt"],
        decode=case["decode"], branch=branch, epoch=epoch, winner=reference["winner"], output_tokens=output,
        bc_execution_s=elapsed, teacher_execution_s=reference["teacher_s"], pd_execution_s=reference["pd_simulated_s"],
        decision_s=result["decision_s"], prefill_s=prefill_s, decode_s=elapsed-prefill_s,
        bc_throughput=output/elapsed, teacher_throughput=output/reference["teacher_s"],
        pd_throughput=output/reference["pd_simulated_s"], bc_over_teacher=reference["teacher_s"]/elapsed,
        bc_over_pd=reference["pd_simulated_s"]/elapsed, host=platform.node())
    for group, count in counts.items():
        row.update({group + "_autonomous_match": count["correct"]/count["total"],
                    group + "_exact_plan_fraction": count["exact"]/count["plans"],
                    group + "_pim_to_npu_fraction": count["pim_to_npu"]/count["total"]})
    return row


def evaluate(root, backend, cases, checkpoint, branch, epoch, workers):
    with ProcessPoolExecutor(max_workers=workers, mp_context=multiprocessing.get_context("spawn")) as pool:
        return list(pool.map(evaluate_case, [(root, backend, case, checkpoint, branch, epoch) for case in cases]))


def prepare(root, backend, source):
    protocol = bc.read(source / "protocol.json")
    cases = [case for case in bc.read(source / "cases.json") if case["model"] == "qwen_7b" and case["split"] != "test"]
    for case in cases:
        cfg = bc.read(case["run_config_path"])
        cfg.update(hardware_json=str(backend / "src/examples/hardware_1npu_2aim.json"),
            pim_config_path=str(backend / "src/aim_simulator/PIM_AiM.json"),
            ramulator_config_path=str(backend / "src/aim_simulator/example.yaml"))
        case["run_config_path"] = str(root / "configs" / f"{case['case_id']:03d}.json")
        bc.write(case["run_config_path"], cfg)
        for folder, suffix in (("anchors", ".jsonl.gz"), ("results", ".json")):
            (root / folder).mkdir(exist_ok=True)
            shutil.copy2(source / folder / f"{case['case_id']:03d}{suffix}", root / folder)
    (root / "initial").mkdir(exist_ok=True)
    checkpoint = source / "training/qwen_7b/epoch_008.pt"
    shutil.copy2(checkpoint, root / "initial/epoch_008.pt")
    assert filecmp.cmp(checkpoint, root / "initial/epoch_008.pt", shallow=False)
    shutil.copy2(source / "training/qwen_7b/epoch_008_cases.csv", root / "initial/epoch_008_cases.csv")
    history = [row for row in csv.DictReader((source / "analysis_no_decision/epoch_aggregated.csv").open()) if row["route"] == "qwen_7b"]
    bc.rows_csv(root / "historical_progress.csv", history)
    protocol.update(source_root=str(source), models=["qwen_7b"], resume_checkpoint=str(root / "initial/epoch_008.pt"),
        source_checkpoint=str(checkpoint), resume_epoch=8, epochs=10,
        branches={"A": "mean plans per task", "B": "equal thirds: prefill, decode t=0/1/2, decode t>=4"},
        primary_metric="sum output tokens / sum simulated execution seconds; all decision overhead excluded",
        counts={split: sum(case["split"] == split for case in cases) for split in ("train", "val")})
    bc.write(root / "cases.json", cases)
    return bc.write(root / "protocol.json", protocol)


def aggregate(branch, epoch, start_epoch, results, train_metrics, val_metrics, elapsed):
    output = sum(row["output_tokens"] for row in results)
    actual, teacher, pd = (sum(row[key] for row in results) for key in ("bc_execution_s", "teacher_execution_s", "pd_execution_s"))
    row = dict(route=branch, model="qwen_7b", epoch=epoch, additional_epoch=epoch-start_epoch,
        train_nll=train_metrics["nll"], val_nll=val_metrics["nll"],
        train_objective_nll=train_metrics["nll" if branch == "A" else "phase_balanced_nll"],
        val_objective_nll=val_metrics["nll" if branch == "A" else "phase_balanced_nll"],
        bc_throughput=output/actual, teacher_throughput=output/teacher, pd_throughput=output/pd,
        teacher_gap_pct=100*(teacher/actual-1), bc_over_teacher=teacher/actual, bc_over_pd=pd/actual,
        decision_s=sum(item["decision_s"] for item in results), epoch_wall_s=elapsed)
    for split, metrics in (("train", train_metrics), ("val", val_metrics)):
        row.update({split + "_" + key: value for key, value in metrics.items() if key != "nll"})
    for group in GROUPS:
        for metric in ("autonomous_match", "exact_plan_fraction", "pim_to_npu_fraction"):
            key = group + "_" + metric
            row[key] = sum(item[key] for item in results)/len(results)
    return row


def report(root, branch, history):
    bc.report(root, branch, history)
    import matplotlib.pyplot as plt
    base = root / "training" / branch
    for metric in ("nll", "teacher_forced_match", "autonomous_match"):
        fig, ax = plt.subplots(figsize=(7, 4))
        for group in GROUPS:
            key = ("val_" if metric != "autonomous_match" else "") + group + "_" + metric
            ax.plot([row["additional_epoch"] for row in history], [row[key] for row in history], marker="o", label=group)
        ax.set(xlabel="Additional epochs from E8", ylabel=metric)
        ax.grid(alpha=.25); ax.legend(); fig.tight_layout()
        for extension in ("png", "svg"):
            fig.savefig(base / "figures" / f"phase_{metric}.{extension}", dpi=170)
        plt.close(fig)
    with (base / "report.md").open("a") as stream:
        stream.write("\nPrimary throughput excludes all decision overhead. Train/val NLL columns retain the original common task-mean definition; objective NLL differs between A and B. Phase match rates are task averages against the original teacher trajectory.\n\nOriginal run (historical, separate from this E8 fork):\n\n|Epoch|BC tokens/s|BC/teacher|BC/PD|\n|---:|---:|---:|---:|\n")
        for row in csv.DictReader((root / "historical_progress.csv").open()):
            stream.write(f"|{row['epoch']}|{float(row['bc_token_s']):.2f}|{100*float(row['bc_over_teacher']):.2f}%|{100*float(row['bc_over_pd']):.2f}%|\n")


def preflight(root, backend, workers):
    protocol, cases = bc.read(root / "protocol.json"), bc.read(root / "cases.json")
    samples = {split: add_phase_weights(bc.load_samples(root, [case for case in cases if case["split"] == split])) for split in ("train", "val")}
    for split_samples in samples.values():
        weights = Counter()
        for row in split_samples:
            weights[row["case_id"], "A"] += row["task_weight"]
            weights[row["case_id"], row["group"]] += row["phase_weight"]
        for (_, group), value in weights.items():
            assert math.isclose(value, 1 if group == "A" else 1/3, rel_tol=1e-12)
    actor, optimizer, rng, epoch = restore(root / "initial/epoch_008.pt", "cuda")
    metrics = {split: teacher_metrics(actor, rows, "cuda", protocol["batch_plans"]) for split, rows in samples.items()}
    expected = next(row for row in csv.DictReader((root / "historical_progress.csv").open()) if int(row["epoch"]) == epoch)
    for split in ("train", "val"):
        assert math.isclose(metrics[split]["nll"], float(expected[split + "_nll"]), rel_tol=1e-5, abs_tol=1e-7)
    results = evaluate(root, backend, [case for case in cases if case["split"] == "val"], root / "initial/epoch_008.pt", "initial", epoch, workers)
    original = {int(row["case_id"]): row for row in csv.DictReader((root / "initial/epoch_008_cases.csv").open())}
    for row in results:
        assert math.isclose(row["bc_execution_s"], float(original[row["case_id"]]["bc_simulated_s"]), rel_tol=1e-8)
    bc.rows_csv(root / "initial/evaluation_cases.csv", results)
    bc.write(root / "initial/phase_metrics.json", metrics)
    return bc.write(root / "preflight_passed.json", dict(complete=True, source_epoch=epoch, all_eight_validation_times_reproduced=True,
        original_nll_reproduced=True, task_and_phase_weights_checked=True, train_tasks=48, val_tasks=8,
        train_plans=len(samples["train"]), val_plans=len(samples["val"]),
        optimizer_steps=sorted({int(value["step"]) for value in optimizer.state.values()}), gpu=torch.cuda.get_device_name(0)))


def train(root, backend, branch, workers):
    assert bc.read(root / "preflight_passed.json")["complete"]
    protocol, cases = bc.read(root / "protocol.json"), bc.read(root / "cases.json")
    base = root / "training" / branch
    base.mkdir(parents=True)
    torch.set_num_threads(1)
    train_cases = [case for case in cases if case["split"] == "train"]
    val_cases = [case for case in cases if case["split"] == "val"]
    samples = add_phase_weights(bc.load_samples(root, train_cases))
    val_samples = add_phase_weights(bc.load_samples(root, val_cases))
    actor, optimizer, rng, start_epoch = restore(root / "initial/epoch_008.pt", "cuda")
    assert start_epoch == protocol["resume_epoch"]
    bc.write(base / "initialized.json", dict(branch=branch, source_checkpoint=protocol["source_checkpoint"],
        start_epoch=start_epoch, additional_epochs=protocol["epochs"], scheme=protocol["branches"][branch],
        network_restored=True, optimizer_restored=True, random_states_restored=True,
        optimizer_steps=sorted({int(value["step"]) for value in optimizer.state.values()}),
        learning_rate=optimizer.param_groups[0]["lr"], host=platform.node(), gpu=torch.cuda.get_device_name(0)))
    initial_results = [{key: (value if key in ("model", "branch", "winner", "host") else float(value)) for key, value in row.items()}
        for row in csv.DictReader((root / "initial/evaluation_cases.csv").open())]
    initial_metrics = bc.read(root / "initial/phase_metrics.json")
    history = [aggregate(branch, start_epoch, start_epoch, initial_results, initial_metrics["train"], initial_metrics["val"], 0)]
    report(root, branch, history)
    for epoch in range(start_epoch+1, start_epoch+protocol["epochs"]+1):
        started = time.perf_counter(); actor.train()
        bc.write(base / "status.json", dict(epoch=epoch, additional_epoch=epoch-start_epoch, stage="training"))
        update_batches = bc.batches(samples, protocol["batch_plans"], rng)
        for rows in update_batches:
            update_batch(actor, optimizer, rows, "cuda", len(samples), len(train_cases), branch, protocol["max_grad_norm"])
        train_metrics = teacher_metrics(actor, samples, "cuda", protocol["batch_plans"])
        val_metrics = teacher_metrics(actor, val_samples, "cuda", protocol["batch_plans"])
        checkpoint = base / f"epoch_{epoch:03d}.pt"
        torch.save(dict(actor={key: value.cpu() for key, value in actor.state_dict().items()}, optimizer=optimizer.state_dict(),
            dimensions=actor.dimensions, epoch=epoch, seed=protocol["seed"], random_state=rng.getstate(),
            torch_rng=torch.get_rng_state(), cuda_rng=torch.cuda.get_rng_state_all(), branch=branch,
            source_checkpoint=protocol["source_checkpoint"]), checkpoint)
        bc.write(base / "status.json", dict(epoch=epoch, additional_epoch=epoch-start_epoch, stage="validation"))
        results = evaluate(root, backend, val_cases, checkpoint, branch, epoch, workers)
        bc.rows_csv(base / f"epoch_{epoch:03d}_cases.csv", results)
        history.append(aggregate(branch, epoch, start_epoch, results, train_metrics, val_metrics, time.perf_counter()-started))
        report(root, branch, history)
        bc.write(base / "status.json", dict(epoch=epoch, additional_epoch=epoch-start_epoch, stage="epoch_complete", row=history[-1]))
        print(json.dumps(history[-1]), flush=True)
    return bc.write(base / "complete.json", dict(complete=True, source_epoch=start_epoch, additional_epochs=protocol["epochs"],
        final_epoch=start_epoch+protocol["epochs"], awaiting_user_before_continuation=True))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("prepare", "preflight", "train"))
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--backend", type=Path, required=True)
    parser.add_argument("--source-root", type=Path)
    parser.add_argument("--branch", choices=("A", "B"))
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    torch.set_num_threads(1)
    result = prepare(args.root, args.backend, args.source_root) if args.stage == "prepare" else preflight(args.root, args.backend, args.workers) if args.stage == "preflight" else train(args.root, args.backend, args.branch, args.workers)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
