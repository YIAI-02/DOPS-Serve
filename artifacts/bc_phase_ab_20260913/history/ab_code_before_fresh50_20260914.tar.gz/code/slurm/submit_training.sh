#!/bin/bash
set -euo pipefail
BC_ROOT=/lustre/home/2501111916/workspace/DOPS-Serve/artifacts/bc_phase_ab_20260913
BC_NODE=${1:?Supply the inspected GPU node shared by A and B}
test -s "$BC_ROOT/preflight_passed.json"
test ! -e "$BC_ROOT/jobs.tsv"
printf 'branch\tjob_id\n' > "$BC_ROOT/jobs.tsv"
for BC_BRANCH in A B; do
    BC_JOB=$(sbatch --parsable -A hpc2006191081 -p GPU80G -q high -w "$BC_NODE" -J "bc26-7b-$BC_BRANCH" -c 16 --gres=gpu:1 -t 04:00:00 -o "$BC_ROOT/logs/train_${BC_BRANCH}_%j.out" "$BC_ROOT/code/slurm/run.sh" train --branch "$BC_BRANCH" --workers 8)
    printf '%s\t%s\n' "$BC_BRANCH" "$BC_JOB" >> "$BC_ROOT/jobs.tsv"
done
cat "$BC_ROOT/jobs.tsv"
