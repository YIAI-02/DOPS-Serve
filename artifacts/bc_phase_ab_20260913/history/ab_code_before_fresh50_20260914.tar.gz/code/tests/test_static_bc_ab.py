import random
import tempfile
import unittest
from collections import Counter
from pathlib import Path

import torch

from dops_serve import static_bc as bc
from dops_serve.placement_policy import StaticPlacementActor
from dops_serve.static_bc_ab import GROUPS, add_phase_weights, restore, update_batch


class BCContinuationContract(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(7)

    def test_phase_balance_preserves_equal_tasks_at_every_decode_length(self):
        rows = []
        for case_id, length in enumerate((128, 256, 512, 1024)):
            indices = [-1, *[t for t in range(length) if bc.refresh(t)]]
            rows.extend(dict(case_id=case_id, phase="prefill" if t == -1 else "decode",
                token_index=t, task_weight=1/len(indices)) for t in indices)
        add_phase_weights(rows)
        totals = Counter()
        for row in rows:
            totals[row['case_id'], 'A'] += row['task_weight']
            totals[row['case_id'], row['group']] += row['phase_weight']
        for case_id in range(4):
            self.assertAlmostEqual(totals[case_id, 'A'], 1)
            for group in GROUPS:
                self.assertAlmostEqual(totals[case_id, group], 1/3)
            startup = [row['token_index'] for row in rows if row['case_id'] == case_id and row['group'] == 'startup_decode']
            self.assertEqual(startup, [0, 1, 2])

    def test_resume_restores_optimizer_rng_and_exact_original_A_update(self):
        actor = StaticPlacementActor(5, 4, hidden=8, depth=1)
        optimizer = torch.optim.Adam(actor.parameters(), lr=1e-4)
        rows = []
        for t in (-1, 0, 1, 2, 4, 6):
            rows.append(dict(case_id=64, model='qwen_7b', phase='prefill' if t == -1 else 'decode',
                token_index=t, task_weight=1/6, state=torch.randn(5), nodes=torch.randn(6, 4),
                actions=torch.tensor([0, 1, 2, 0, 1, 2]), masks=torch.ones(6, 3, dtype=torch.bool), learned=torch.ones(6)))
        add_phase_weights(rows)
        update_batch(actor, optimizer, rows[:2], 'cpu', 6, 1, 'A', 1.)
        rng = random.Random(7)
        bc.batches(rows, 2, rng)
        saved_rng = rng.getstate()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'e8.pt'
            torch.save(dict(actor=actor.state_dict(), optimizer=optimizer.state_dict(), dimensions=actor.dimensions,
                epoch=8, random_state=saved_rng, torch_rng=torch.get_rng_state(), cuda_rng=[]), path)
            expected_random = torch.rand(5)
            resumed, resumed_optimizer, resumed_rng, epoch = restore(path, 'cpu')
            self.assertEqual(epoch, 8)
            torch.testing.assert_close(torch.rand(5), expected_random, rtol=0, atol=0)
            torch.testing.assert_close(resumed_optimizer.state_dict(), optimizer.state_dict(), rtol=0, atol=0)
            original_batches = bc.batches(rows, 2, rng)
            resumed_batches = bc.batches(rows, 2, resumed_rng)
            self.assertEqual([[r['token_index'] for r in b] for b in original_batches],
                             [[r['token_index'] for r in b] for b in resumed_batches])
            _, _, branch_b_rng, _ = restore(path, 'cpu')
            self.assertEqual([[r['token_index'] for r in b] for b in bc.batches(rows, 2, branch_b_rng)],
                             [[r['token_index'] for r in b] for b in original_batches])
            original = original_batches[0]
            optimizer.zero_grad(set_to_none=True)
            loss, _ = actor(*bc.batch_tensors(original, 'cpu'))
            value = (loss*torch.tensor([row['task_weight'] for row in original])).mean()*6
            value.backward()
            torch.nn.utils.clip_grad_norm_(actor.parameters(), 1.)
            optimizer.step()
            update_batch(resumed, resumed_optimizer, resumed_batches[0], 'cpu', 6, 1, 'A', 1.)
            torch.testing.assert_close(resumed.state_dict(), actor.state_dict(), rtol=0, atol=0)
            torch.testing.assert_close(resumed_optimizer.state_dict(), optimizer.state_dict(), rtol=0, atol=0)


if __name__ == '__main__':
    unittest.main()
