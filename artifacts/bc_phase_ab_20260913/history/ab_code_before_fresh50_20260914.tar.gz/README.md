# Qwen-7B E8：BC A/B 续训对照

用户于 2026-09-13 确认执行。只训练 7B；两个分支从同一个 E8 检查点追加 10 个 epoch。

|项目|A|B|
|---|---|---|
|起点|原 7B E8 网络、Adam、随机状态|相同|
|计划权重|每任务内所有计划等权|prefill、decode t=0/1/2、decode t>=4 各占 1/3，组内等权|
|学习率 / batch / clip|1e-4 / 16 份计划 / 1|相同|
|训练数据与批次顺序|48 个原训练任务、11616 个现场|相同|
|验证|8 个原验证任务、1936 个现场；完整自主回放|相同|
|轮次|E8 为 +0，追加 +1…+10，对应 E9…E18|相同|

## 保留与边界

- 沿用 C026 的 DOPS fast 配置、唯一完整赢家、具体三设备动作、原网络及 decode stride=2。
- 复制现有 7B train/val 现场和评分，不重新生成教师；不读取 test 结果。
- 新目录单独保存代码、后端、日志、检查点和结果；不覆盖原实验。
- 主吞吐统一为总输出 token / 总模拟执行时间，排除双方决策耗时。BC 决策耗时另记。
- 不增加自身现场数据、不调整网络或学习率，本次只检验 loss 权重。
- 两分支各完成追加 10 轮后停止；不自动开 PPO；按用户后续授权，每小时监控一次，整批结束后暂停监控。

## 实现与验收

- 入口：`code/src/dops_serve/static_bc_ab.py`。复用原 `static_bc` 数据、批次、网络和 DOPS 回放；为逐计划统计加一个回调。
- 恢复网络、Adam 动量/步数、Python 批次随机状态、PyTorch CPU/CUDA 状态。
- 单元检查：三阶段权重和任务等权；断点恢复后的 A 更新与原公式参数、优化器状态完全一致；A/B 批次顺序相同。
- HPC 预检：复现 E8 原训练/验证 NLL，以及 8 个验证任务的执行时间，再提交 A/B。
- 每轮记录公共原口径 NLL、各分支实际目标 NLL、三阶段训练/验证 NLL、教师前缀和完整自主执行的动作一致率、PIM→NPU 偏离比例、完整吞吐和决策耗时。不同分支的目标 NLL 不直接横比。

## 工件与执行

HPC：`/lustre/home/2501111916/workspace/DOPS-Serve/artifacts/bc_phase_ab_20260913/`。

- `initial/epoch_008.pt`：共同起点；`initial/evaluation_cases.csv`、`phase_metrics.json`：共同基准。
- `training/A/`、`training/B/`：逐轮 CSV、检查点、阶段曲线、报告及状态。
- `historical_progress.csv`：原实验 E1–E10，明确与新分支分开标记。
- `protocol.json`、`preflight_passed.json`、`jobs.tsv`：配置、验收和作业编号。
- 登录节点只准备文件和提交；数据节点上传代码；单元检查、回放和训练都在 Slurm 计算节点运行。

提交脚本为 `code/slurm/run.sh` 和 `submit_training.sh`；后者要求传入现场核对过的 GPU 节点，将 A/B 放到同一节点以保持硬件一致。
