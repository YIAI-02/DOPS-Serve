import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from dops_serve.placement_evaluator import PlacementEvaluator
from dops_serve.replay import PlacementReplay


class PlacementReplayTest(unittest.TestCase):
    def test_idle_gap_ends_at_the_next_observable_decision_boundary(self):
        repo = Path(__file__).resolve().parents[1]
        backend = os.environ.get("DOPS_BACKEND_ROOT", repo / "artifacts/qwen_1npu2pim_op_policy_v1/backend/DOPS")
        config = json.loads((repo / "configs/op_policy_v1.json").read_text())
        with tempfile.TemporaryDirectory() as directory:
            evaluator = PlacementEvaluator(backend, directory, "qwen_1.8b", config)
            records = [{"request_id": name, "arrival_time": arrival, "prompt_len": 128, "max_tokens": 1024, "output_len": 2} for name, arrival in (("a", 0.0), ("b", 100.0))]
            replay = PlacementReplay(records, evaluator, slo_s=1, decode_window=1)
            plans = {p: evaluator.compiler.compile(evaluator.compiler.uniform(0)) for p in ("prefill", "decode")}
            with patch("dops_serve.replay.time.perf_counter", return_value=0.0):
                result = replay.run_window(lambda state, current: plans, {"a_N": 0, "a_T": 1, "lambda_q": 0, "lambda_l": 0})
            self.assertFalse(result["terminal"])
            self.assertEqual(result["duration_s"], 100.0)
            self.assertEqual(result["reward"], -100.0)
            self.assertEqual([r["request_id"] for r in replay.observation()["waiting"]], ["b"])

    def test_decision_pause_collects_arrivals_and_prefill_only_trace_finishes(self):
        repo = Path(__file__).resolve().parents[1]
        backend = Path(os.environ.get("DOPS_BACKEND_ROOT", repo / "artifacts/qwen_1npu2pim_op_policy_v1/backend/DOPS"))
        config = json.loads((repo / "configs/op_policy_v1.json").read_text())
        with tempfile.TemporaryDirectory() as directory:
            evaluator = PlacementEvaluator(backend, directory, "qwen_1.8b", config)
            records = [{"request_id": name, "arrival_time": arrival, "prompt_len": 128, "max_tokens": 1024, "output_len": 1} for name, arrival in (("a", 0.0), ("b", 0.5))]
            replay = PlacementReplay(records, evaluator, slo_s=0.75)
            observations = []

            def decide(state, current):
                observations.append(state)
                return {p: evaluator.compiler.compile(evaluator.compiler.uniform(0)) for p in ("prefill", "decode")}

            times = iter((0.0, 1.0))
            with patch("dops_serve.replay.time.perf_counter", side_effect=lambda: next(times, 1.0)):
                result = replay.run_window(decide, {"a_N": 1.0, "a_T": 1.0, "lambda_q": 1.0, "lambda_l": 1.0})
            self.assertTrue(result["terminal"])
            self.assertEqual(result["decision_s"], 1.0)
            self.assertEqual(result["decode_iterations"], 0)
            self.assertEqual(result["output_tokens"], 2)
            self.assertEqual(result["waiting_s"], 1.5)
            self.assertEqual([r["request_id"] for r in observations[0]["waiting"]], ["a"])
            self.assertEqual([(s["phase"], s["request_ids"]) for s in replay.step_results], [("prefill", ["a", "b"])])
            self.assertTrue(all(r["prefill_start"] == 1.0 for r in replay.request_metrics()))

    def test_prefill_first_token_refill_drain_rewards_and_window_truncation(self):
        repo = Path(__file__).resolve().parents[1]
        backend = Path(os.environ.get("DOPS_BACKEND_ROOT", repo / "artifacts/qwen_1npu2pim_op_policy_v1/backend/DOPS"))
        config = json.loads((repo / "configs/op_policy_v1.json").read_text())
        with tempfile.TemporaryDirectory() as directory:
            evaluator = PlacementEvaluator(backend, directory, "qwen_1.8b", config)
            records = [
                {"request_id": "a", "arrival_time": 0.0, "prompt_len": 128, "max_tokens": 1024, "output_len": 3},
                {"request_id": "b", "arrival_time": 0.0, "prompt_len": 256, "max_tokens": 1024, "output_len": 1},
                {"request_id": "c", "arrival_time": 1e-9, "prompt_len": 128, "max_tokens": 1024, "output_len": 2},
            ]
            replay = PlacementReplay(records, evaluator, slo_s=0.0001, max_batch=2, decode_window=1)
            seen = []

            def decide(observation, current):
                seen.append(observation)
                self.assertNotIn("output_len", json.dumps(observation))
                return {phase: evaluator.compiler.compile(evaluator.compiler.uniform(0)) for phase in ("prefill", "decode")}

            coefficients = {"a_N": 1.0, "a_T": 1.0, "lambda_q": 1.0, "lambda_l": 1.0}
            with patch("dops_serve.replay.time.perf_counter", return_value=0.0):
                first = replay.run_window(decide, coefficients)
                self.assertFalse(first["terminal"])
                self.assertEqual(first["decode_iterations"], 1)
                self.assertEqual(replay.snapshot.kv_written_tokens, {"a": 129})
                second = replay.run_window(decide, coefficients)
            self.assertTrue(second["terminal"])
            self.assertEqual(replay.total_decode_iterations, 2)
            self.assertEqual(sum(w["output_tokens"] for w in replay.windows), 6)
            self.assertEqual([(r["phase"], r["request_ids"]) for r in replay.step_results], [("prefill", ["a", "b"]), ("decode", ["a"]), ("prefill", ["c"]), ("decode", ["a", "c"])])
            metrics = {r["request_id"]: r for r in replay.request_metrics()}
            self.assertIsNone(metrics["b"]["tpot_s"])
            self.assertEqual(metrics["b"]["first_token_time"], metrics["b"]["completion_time"])
            self.assertEqual(len(metrics["a"]["tbt_s"]), 2)
            self.assertEqual(replay.snapshot.kv_reserved_tokens, {})
            self.assertEqual(replay.snapshot.scheduler.label.kv_bytes_by_pim, {"PIM0": 0, "PIM1": 0})
            self.assertAlmostEqual(sum(w["waiting_s"] for w in replay.windows), sum(r["queue_wait_s"] for r in metrics.values()))
            self.assertEqual(sum(w["new_violations"] for w in replay.windows), sum(r["e2e_violated"] for r in metrics.values()))
            self.assertAlmostEqual(sum(w["overdue_s"] for w in replay.windows), sum(max(0.0, r["e2e_s"] - replay.slo_s) for r in metrics.values()))


if __name__ == "__main__":
    unittest.main()
