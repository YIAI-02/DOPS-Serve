from __future__ import annotations

import copy
import json
import random
import time
from pathlib import Path

import torch

from .placement_policy import PlacementActor, LearnedPlacement, policy_inputs


def cost_weights(costs, temperature):
    costs = torch.as_tensor(costs, dtype=torch.float64)
    # Relative costs compare only candidates sharing the exact same anchor.
    return torch.softmax(-(costs / costs.min() - 1) / temperature, dim=0)


def block_returns(windows, bootstrap):
    """Gamma=1, lambda=1; only the last block receives each window reward."""
    returns = []
    running = float(bootstrap)
    for window in reversed(windows):
        if window["terminal"]:
            running = 0.0
        running += window["reward"]
        returns.append([running] * len(window["values"]))
    return list(reversed(returns))


def ppo_loss(new_log_probs, old_log_probs, advantages, values, returns, entropies, *, clip, value_coefficient, entropy_coefficient):
    ratios = (new_log_probs - old_log_probs).exp()
    surrogate = torch.minimum(ratios * advantages, ratios.clamp(1 - clip, 1 + clip) * advantages)
    loss = -surrogate.mean() + value_coefficient * (values - returns).square().mean() - entropy_coefficient * entropies.mean()
    return loss, {"clip_fraction": float(((ratios - 1).abs() > clip).float().mean().detach()), "approx_kl": float(((ratios - 1) - ratios.log()).mean().detach())}


def load_actor(path):
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    actor = PlacementActor(**checkpoint["dimensions"])
    actor.load_state_dict(checkpoint["state_dict"])
    return actor, checkpoint


def _save(actor, path, **metadata):
    torch.save({"state_dict": actor.state_dict(), "dimensions": actor.dimensions, **metadata}, path)


def _anchor_files(directory, exclude_model):
    summary = json.loads((directory / "reevaluation_summary.json").read_text())
    if not summary["complete"]:
        raise ValueError("BC requires complete historical reevaluation")
    files = {split: [] for split in ("train", "val")}
    for item in summary["files"]:
        if exclude_model and Path(item["path"]).name.startswith(exclude_model + "_"):
            continue
        files[item["split"]].append(Path(item["path"]))
    if not all(files.values()):
        raise ValueError("BC requires distinct training and validation conditions")
    return files


def _bc_validation(actor, files, programs):
    regret, nll, anchors = 0.0, 0.0, 0
    with torch.no_grad():
        for path in files:
            for row in map(json.loads, path.open()):
                scores = [float(actor.sequence(row["inputs"], programs[c["placement_id"]])["log_probs"].sum()) for c in row["candidates"]]
                best = max(range(len(scores)), key=scores.__getitem__)
                minimum = min(c["cost_s"] for c in row["candidates"])
                regret += row["candidates"][best]["cost_s"] / minimum - 1
                nll -= sum(scores) / len(scores) / sum(map(len, row["inputs"]["nodes"]))
                anchors += 1
    return {"candidate_regret": regret / anchors, "unweighted_nll": nll / anchors, "anchors": anchors}


def train_bc(artifact_dir, output_dir, *, seed=7, epochs=3, temperature=1.0, learning_rate=3e-4, exclude_model=None):
    torch.set_num_threads(1)
    torch.manual_seed(seed)
    rng = random.Random(seed)
    directory, destination = Path(artifact_dir), Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    files = _anchor_files(directory, exclude_model)
    programs = {row["placement_id"]: row["block_actions"] for row in map(json.loads, (directory / "placements.jsonl").open())}
    with files["train"][0].open() as handle:
        sample = json.loads(next(handle))["inputs"]
    actor = PlacementActor(len(sample["state"]), len(sample["nodes"][0][0]))
    parameter_count = sum(p.numel() for p in actor.parameters())
    if parameter_count >= 1_000_000:
        raise ValueError("actor and value exceed the proposal parameter budget")
    optimizer = torch.optim.Adam(actor.parameters(), lr=learning_rate)
    history, best = [], (float("inf"), float("inf"))
    with (destination / "bc_curve.jsonl").open("w") as curve:
        for epoch in range(epochs):
            started = time.perf_counter()
            paths = list(files["train"])
            rng.shuffle(paths)
            total_loss, count = 0.0, 0
            for path in paths:
                rows = [json.loads(line) for line in path.open()]
                rng.shuffle(rows)
                for row in rows:
                    weights = cost_weights([c["cost_s"] for c in row["candidates"]], temperature)
                    node_count = sum(map(len, row["inputs"]["nodes"]))
                    optimizer.zero_grad()
                    loss_value = 0.0
                    for weight, candidate in zip(weights, row["candidates"]):
                        result = actor.sequence(row["inputs"], programs[candidate["placement_id"]])
                        loss = -weight.float() * result["log_probs"].sum() / node_count
                        loss.backward()
                        loss_value += float(loss.detach())
                    torch.nn.utils.clip_grad_norm_(actor.parameters(), 1.0)
                    optimizer.step()
                    total_loss += loss_value
                    count += 1
                    if count % 500 == 0:
                        print(json.dumps({"bc_epoch": epoch + 1, "anchors": count, "loss": total_loss / count}), flush=True)
            validation = _bc_validation(actor, files["val"], programs)
            record = {"epoch": epoch + 1, "training_loss": total_loss / count, "validation": validation, "wall_s": time.perf_counter() - started}
            history.append(record)
            curve.write(json.dumps(record) + "\n")
            curve.flush()
            rank = (validation["candidate_regret"], validation["unweighted_nll"])
            if rank < best:
                best = rank
                _save(actor, destination / "bc.pt", stage="BC", seed=seed, epoch=epoch + 1, temperature=temperature, learning_rate=learning_rate, exclude_model=exclude_model, validation=validation)
            print(json.dumps(record), flush=True)
    result = {"stage": "BC", "seed": seed, "epochs": epochs, "temperature": temperature, "parameter_count": parameter_count, "exclude_model": exclude_model, "checkpoint": str(destination / "bc.pt"), "history": history}
    (destination / "bc_summary.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def update_ppo(actor, optimizer, windows, bootstrap, settings):
    returns = [torch.tensor(row, dtype=torch.float32) for row in block_returns(windows, bootstrap)]
    advantages = [ret - torch.tensor(row["values"]) for ret, row in zip(returns, windows)]
    combined = torch.cat(advantages)
    mean, std = combined.mean(), combined.std(unbiased=False).clamp_min(1e-8)
    advantages = [(value - mean) / std for value in advantages]
    logs = []
    for _ in range(settings["ppo_epochs"]):
        optimizer.zero_grad()
        for row, ret, advantage in zip(windows, returns, advantages):
            result = actor.pair(row["inputs"], row["programs"])
            loss, log = ppo_loss(result["log_probs"], torch.tensor(row["log_probs"]), advantage, result["values"], ret, result["entropies"], clip=settings["clip"], value_coefficient=settings["value_coefficient"], entropy_coefficient=settings["entropy_coefficient"])
            (loss / len(windows)).backward()
            logs.append({"loss": float(loss.detach()), **log})
        torch.nn.utils.clip_grad_norm_(actor.parameters(), settings["max_grad_norm"])
        optimizer.step()
    return {key: sum(row[key] for row in logs) / len(logs) for key in logs[0]}


def train_ppo(backend_root, artifact_dir, config, checkpoint_path, output_dir, protocol, *, seed=7, exclude_model=None, trace_epochs=None):
    from .placement_evaluator import PlacementEvaluator
    from .placement_evaluation import load_traces, scaled_trace
    from .replay import PlacementReplay

    torch.set_num_threads(1)
    torch.manual_seed(seed)
    rng = random.Random(seed)
    actor, checkpoint = load_actor(checkpoint_path)
    if checkpoint["exclude_model"] != exclude_model:
        raise ValueError("BC checkpoint model split differs from PPO")
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    if Path(checkpoint_path).resolve() == (destination / "ppo.pt").resolve():
        raise ValueError("PPO continuation requires a separate output directory")
    settings = protocol["ppo"]
    if protocol["backend_config"] != config or settings["gamma"] != 1.0 or settings["gae_lambda"] != 1.0:
        raise ValueError("PPO must use the calibrated backend and undiscounted block-return protocol")
    optimizer = torch.optim.Adam(actor.parameters(), lr=settings["learning_rate"])
    continuing = checkpoint["stage"] == "PPO"
    restore_optimizer = continuing and "optimizer_state_dict" in checkpoint
    if continuing and checkpoint["seed"] != seed:
        raise ValueError("PPO continuation must retain its original seed")
    if continuing and checkpoint["protocol"] != protocol:
        raise ValueError("PPO continuation must retain the original calibrated protocol")
    if restore_optimizer:
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        torch.set_rng_state(checkpoint["torch_rng_state"])
        rng.setstate(checkpoint["python_rng_state"])
    traces = load_traces(artifact_dir, "train", protocol["train_trace_ids"])
    models = [m for m in config["models"] if m != exclude_model]
    evaluators = {m: PlacementEvaluator(backend_root, destination / "backend", m, config) for m in models}
    schedule = [(model, trace_id) for model in models for trace_id in traces]
    updates = checkpoint["updates"] if continuing else 0
    totals = list(checkpoint["completed_traces"]) if continuing else []
    previous_epochs = max((row["epoch"] for row in totals), default=0)
    # Legacy pilot checkpoints lack Adam/RNG state. Reconstruct the schedule;
    # explicitly report the fresh Adam and Torch RNG instead of claiming exact resume.
    if continuing and not restore_optimizer:
        for _ in range(previous_epochs):
            rng.shuffle(schedule)
            for _ in schedule:
                rng.choice(protocol["training_load_multipliers"])
    elif restore_optimizer:
        schedule = [tuple(pair) for pair in checkpoint["schedule"]]
    epochs = settings["trace_epochs"] if trace_epochs is None else trace_epochs
    continuation = "exact optimizer/RNG resume" if restore_optimizer else "weights only; fresh Adam and Torch RNG" if continuing else "BC initialization"
    with (destination / "ppo_curve.jsonl").open("w") as curve:
        for epoch in range(previous_epochs, previous_epochs + epochs):
            rng.shuffle(schedule)
            for model, trace_id in schedule:
                load = rng.choice(protocol["training_load_multipliers"])
                model_protocol = protocol["models"][model]
                records = scaled_trace(traces[trace_id], model_protocol["reference_rps"] * load)
                replay = PlacementReplay(records, evaluators[model], slo_s=model_protocol["slo_s"], max_batch=config["max_batch"], decode_window=config["decode_window"])
                selector = LearnedPlacement(actor, evaluators[model], deterministic=False)
                while not replay.done:
                    windows = []
                    for _ in range(settings["rollout_windows"]):
                        result = replay.run_window(selector, model_protocol["reward"])
                        windows.append({**copy.deepcopy(selector.last), "reward": result["reward"], "terminal": result["terminal"]})
                        if replay.done:
                            break
                    bootstrap = 0.0
                    if not replay.done:
                        current = evaluators[model].compiler.project(replay.plans["prefill"]["device_by_node"])
                        inputs = policy_inputs(replay.observation(), evaluators[model], "prefill", current)
                        with torch.no_grad():
                            bootstrap = float(actor.sequence(inputs, deterministic=True)["values"][0])
                    log = update_ppo(actor, optimizer, windows, bootstrap, settings)
                    updates += 1
                    record = {"epoch": epoch + 1, "update": updates, "model": model, "trace_id": trace_id, "load": load, "terminal": replay.done, "windows": len(windows), "reward": sum(w["reward"] for w in windows), **log}
                    curve.write(json.dumps(record) + "\n")
                    curve.flush()
                    print(json.dumps(record), flush=True)
                totals.append({"epoch": epoch + 1, "model": model, "trace_id": trace_id, "load_multiplier": load, "completed": len(replay.completed), "windows": len(replay.windows)})
            _save(actor, destination / "ppo.pt", stage="PPO", seed=seed, updates=updates, exclude_model=exclude_model,
                  protocol=protocol, completed_traces=totals, optimizer_state_dict=optimizer.state_dict(),
                  torch_rng_state=torch.get_rng_state(), python_rng_state=rng.getstate(), schedule=schedule,
                  source_checkpoint=str(checkpoint_path), continuation=continuation)
    result = {"stage": "PPO", "seed": seed, "updates": updates, "additional_trace_epochs": epochs, "continuation": continuation,
              "source_checkpoint": str(checkpoint_path), "completed_traces": totals, "checkpoint": str(destination / "ppo.pt")}
    (destination / "ppo_summary.json").write_text(json.dumps(result, indent=2) + "\n")
    return result
