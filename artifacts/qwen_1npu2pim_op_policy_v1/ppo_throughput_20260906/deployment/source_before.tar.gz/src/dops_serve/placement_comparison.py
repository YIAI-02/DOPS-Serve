"""Paired validation of Static, fixed-order Bifocal, BC and PPO checkpoints."""
from __future__ import annotations

import json
import platform
import statistics
import time
from pathlib import Path

from .placement_evaluation import StaticPlacement, load_traces, replay_metrics, scaled_trace
from .placement_evaluator import PlacementEvaluator
from .replay import PlacementReplay


def prepare_comparison(artifact_dir, output_dir, protocol, *, continued_dir=None):
    source, destination = Path(artifact_dir), Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    methods = [{"method": method, "seed": None, "checkpoint": None} for method in ("static", "bifocal")]
    for method in ("bc", "ppo"):
        methods.extend({"method": method, "seed": seed, "checkpoint": str(source / "learning" / f"seed_{seed}" / f"{method}.pt")} for seed in (7, 17, 27))
    if continued_dir:
        methods.extend({"method": "ppo_continued", "seed": seed, "checkpoint": str(Path(continued_dir) / f"seed_{seed}" / "ppo.pt")} for seed in (7, 17, 27))
    cases = []
    for method in methods:
        for model in protocol["models"]:
            for load in protocol["test_load_multipliers"]:
                cases.append({"case_id": len(cases), **method, "model": model, "load_multiplier": load})
    result = {
        "split": "val", "purpose": "compare pilot and continuation on fixed validation data; no test-based training decisions",
        "trace_ids": protocol["validation_trace_ids"], "protocol": protocol, "cases": cases,
        "scope": protocol["scope"], "slo_violation_limit": 0.01,
        "bifocal": "pinned backend score and configuration; fixed topological order; NPU or node's fixed PIM; no actual remaining output length",
        "learned_decoding": "deterministic argmax; identical to deployment selection",
        "decision_overhead": "measured selector, feature, compile and search wall time is charged to simulated serving time",
    }
    (destination / "comparison_cases.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def evaluate_case(backend_root, artifact_dir, output_dir, case_id):
    import torch
    from .placement_policy import LearnedPlacement
    from .placement_training import load_actor

    torch.set_num_threads(1)
    destination = Path(output_dir)
    manifest = json.loads((destination / "comparison_cases.json").read_text())
    case = manifest["cases"][case_id]
    protocol = manifest["protocol"]
    config, model = protocol["backend_config"], case["model"]
    calibration = protocol["models"][model]
    traces = load_traces(artifact_dir, manifest["split"], manifest["trace_ids"])
    folder = destination / "cases" / f"{case_id:03d}"
    folder.mkdir(parents=True, exist_ok=True)
    evaluator = PlacementEvaluator(backend_root, folder / "backend", model, config)
    actor, checkpoint = None, None
    if case["checkpoint"]:
        actor, checkpoint = load_actor(case["checkpoint"])
        expected_stage = "BC" if case["method"] == "bc" else "PPO"
        if checkpoint["stage"] != expected_stage or checkpoint["seed"] != case["seed"] or checkpoint["exclude_model"] is not None:
            raise ValueError("comparison checkpoint differs from the declared method, seed or model split")
        if expected_stage == "PPO" and checkpoint["protocol"] != protocol:
            raise ValueError("PPO checkpoint and comparison protocol differ")
        actor.eval()
    results, baseline_config = [], None
    for trace_id, rows in traces.items():
        records = scaled_trace(rows, calibration["reference_rps"] * case["load_multiplier"])
        replay = PlacementReplay(records, evaluator, slo_s=calibration["slo_s"], max_batch=config["max_batch"], decode_window=config["decode_window"])
        if case["method"] == "static":
            selector = StaticPlacement(evaluator, calibration["static"]["programs"])
        elif case["method"] == "bifocal":
            from .placement_baselines import FixedOrderBifocalPlacement
            from scheduler import scheduler_bifocal as bifocal
            baseline_config = {key: getattr(bifocal, key) for key in (
                "SCHED_JOINT_LK_ENABLE", "SCHED_JOINT_LK_H", "SCHED_JOINT_LK_GAMMA",
                "SCHED_JOINT_LK_CONSIST_LAMBDA", "SCHED_JOINT_LK_PLAN_HINT_MAX", "SCHED_WEIGHT_BIAS_ETA",
            )}
            selector = FixedOrderBifocalPlacement(evaluator, lambda: replay.snapshot, max_batch=config["max_batch"], seed=7)
        else:
            selector = LearnedPlacement(actor, evaluator, deterministic=True)
        started = time.perf_counter()
        while not replay.done:
            replay.run_window(selector, calibration["reward"])
            if len(replay.windows) % 50 == 0:
                print(json.dumps({"case_id": case_id, "trace_id": trace_id, "windows": len(replay.windows), "completed": len(replay.completed)}), flush=True)
        metrics = replay_metrics(replay, time.perf_counter() - started)
        result = {"trace_id": trace_id, **metrics, "cumulative_reward": sum(w["reward"] for w in replay.windows), "windows": len(replay.windows)}
        results.append(result)
        (folder / f"{trace_id}_windows.jsonl").write_text("".join(json.dumps(w) + "\n" for w in replay.windows))
        (folder / f"{trace_id}_requests.jsonl").write_text("".join(json.dumps(r) + "\n" for r in replay.request_metrics()))
    result = {
        **case, "split": manifest["split"], "scope": manifest["scope"], "host": platform.node(),
        "slo_s": calibration["slo_s"], "reference_rps": calibration["reference_rps"], "traces": results, "baseline_config": baseline_config,
        "checkpoint_metadata": {k: checkpoint[k] for k in ("stage", "seed", "epoch", "updates", "continuation") if checkpoint is not None and k in checkpoint},
    }
    (folder / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def summarize_comparison(output_dir):
    destination = Path(output_dir)
    manifest = json.loads((destination / "comparison_cases.json").read_text())
    rows, missing = [], []
    for case in manifest["cases"]:
        path = destination / "cases" / f"{case['case_id']:03d}" / "result.json"
        if not path.exists():
            missing.append(case["case_id"])
            continue
        result = json.loads(path.read_text())
        if any(result[key] != case[key] for key in case) or [r["trace_id"] for r in result["traces"]] != manifest["trace_ids"]:
            raise ValueError(f"case {case['case_id']} does not match the comparison manifest")
        if any(r["requests"] != 1000 for r in result["traces"]):
            raise ValueError("comparison requires full 1000-request traces")
        rows.extend({**case, **trace} for trace in result["traces"])
    paired = []
    index = {(r["method"], r["seed"], r["model"], r["load_multiplier"], r["trace_id"]): r for r in rows}
    for row in rows:
        if row["method"] not in ("ppo", "ppo_continued"):
            continue
        reference = "bc" if row["method"] == "ppo" else "ppo"
        before = index.get((reference, row["seed"], row["model"], row["load_multiplier"], row["trace_id"]))
        if before is None:
            continue
        paired.append({
            **{k: row[k] for k in ("model", "seed", "load_multiplier", "trace_id")},
            "before": reference, "after": row["method"],
            "throughput_change_pct": 100 * (row["output_token_throughput"] / before["output_token_throughput"] - 1),
            "p99_change_pct": 100 * (row["e2e_p99_s"] / before["e2e_p99_s"] - 1),
            "violation_change_pp": 100 * (row["e2e_violation_rate"] - before["e2e_violation_rate"]),
            "before_slo_pass": before["e2e_violation_rate"] <= 0.01,
            "after_slo_pass": row["e2e_violation_rate"] <= 0.01,
        })
    capacity = []
    groups = sorted({(r["method"], r["seed"] or 0, r["model"]) for r in rows})
    for method, seed, model in groups:
        group = [r for r in rows if (r["method"], r["seed"] or 0, r["model"]) == (method, seed, model)]
        loads = []
        for load in manifest["protocol"]["test_load_multipliers"]:
            subset = [r for r in group if r["load_multiplier"] == load]
            if len(subset) != len(manifest["trace_ids"]):
                continue
            violation = sum(r["e2e_violations"] for r in subset) / sum(r["requests"] for r in subset)
            throughput = sum(r["output_tokens"] for r in subset) / sum(r["duration_s"] for r in subset)
            loads.append({"load_multiplier": load, "violation_rate": violation, "throughput": throughput})
        feasible = [r for r in loads if r["violation_rate"] <= 0.01]
        best = max(feasible, key=lambda r: r["throughput"]) if feasible else None
        capacity.append({"method": method, "seed": seed or None, "model": model, "complete_load_scan": len(loads) == 5, "slo_feasible_best": best, "loads": loads})
    result = {"complete": not missing, "missing_cases": missing, "completed_cases": len(manifest["cases"]) - len(missing),
              "split": manifest["split"], "scope": manifest["scope"], "capacity": capacity, "paired": paired}
    (destination / "comparison_summary.json").write_text(json.dumps(result, indent=2) + "\n")
    lines = ["# 固定验证集上的策略比较", "", f"完成 {result['completed_cases']}/{len(manifest['cases'])} 个条件。范围：{manifest['scope']}。", "",
             "吞吐只在已扫描负载中选择，E2E 违约率须不超过 1%；无达标档位记为未达标。测试集未使用。", "",
             "| 方法 | 种子 | 模型 | 五档完整 | 达标最高 token/s | 对应负载 |", "|---|---:|---|---|---:|---:|"]
    for row in capacity:
        best = row["slo_feasible_best"]
        lines.append(f"| {row['method']} | {row['seed'] or '固定'} | {row['model']} | {row['complete_load_scan']} | {best['throughput']:.4f} | {best['load_multiplier']} |" if best else f"| {row['method']} | {row['seed'] or '固定'} | {row['model']} | {row['complete_load_scan']} | 未达标 | — |")
    lines.extend(["", "## 同条件配对变化", "", "正吞吐变化表示更快；负 p99/违约率变化表示改善。随机种子全部保留，不按验证结果挑种子。", "",
                  "| 比较 | 模型 | 配对数 | 吞吐变化均值 | p99 变化均值 | 违约率变化（百分点） |", "|---|---|---:|---:|---:|---:|"])
    for after in ("ppo", "ppo_continued"):
        for model in manifest["protocol"]["models"]:
            group = [r for r in paired if r["after"] == after and r["model"] == model]
            if group:
                means = [statistics.fmean(r[key] for r in group) for key in ("throughput_change_pct", "p99_change_pct", "violation_change_pp")]
                lines.append(f"| {group[0]['before']} → {after} | {model} | {len(group)} | {means[0]:+.2f}% | {means[1]:+.2f}% | {means[2]:+.2f} |")
    if missing:
        lines.extend(["", "仍有未完成条件，以上为部分结果，不能用于宣布整体优胜。"])
    lines.extend(["", "单条验证 trace 的比较不足以证明泛化或稳定收益。续训是否改善应同时检查各模型、各种子的达标吞吐及配对延迟，不能仅看训练 reward。"])
    (destination / "comparison_summary.md").write_text("\n".join(lines) + "\n")
    return result
