import json
import tempfile
import unittest
from pathlib import Path

from dops_serve.placement_comparison import prepare_comparison, select_epochs, read_throughput_results, epoch_scores
from dops_serve.placement_training import throughput_schedule


MODELS = ["qwen_1.8b", "qwen_7b", "qwen_14b"]
SEEDS = [7, 17, 27]


def score(gain, noise=0.001):
    individual = [{"model": model, "seed": seed, "repeats": [gain - noise / 2, gain, gain + noise / 2],
                   "median": gain, "range": noise} for model in MODELS for seed in SEEDS]
    return {"median": gain, "range": noise, "individual": individual}


class ThroughputTest(unittest.TestCase):
    def test_rotating_schedule_balances_each_epoch_and_covers_five_loads(self):
        protocol = {"backend_config": {"models": MODELS}, "train_trace_ids": [f"t{i}" for i in range(10)],
                    "training_load_multipliers": [0.5, 0.75, 1, 1.25, 1.5]}
        for seed in SEEDS:
            seen = {}
            for epoch in range(5):
                rows = throughput_schedule(protocol, epoch, seed)
                self.assertEqual(len(rows), 30)
                self.assertEqual(rows[0][0], MODELS[epoch % 3])
                for model in MODELS:
                    self.assertEqual(sorted(r[2] for r in rows if r[0] == model), sorted(protocol["training_load_multipliers"] * 2))
                for model, trace, load in rows:
                    seen.setdefault((model, trace), set()).add(load)
            self.assertTrue(all(len(loads) == 5 for loads in seen.values()))

    def test_three_no_new_best_epochs_stop_and_rebound_does_not_reset(self):
        decisions = select_epochs([score(0), score(.02), score(.01), score(.018), score(.0195), score(.10)])
        self.assertEqual([r["no_improvement"] for r in decisions], [0, 0, 1, 2, 3])
        self.assertFalse(decisions[2]["stop"])
        self.assertFalse(decisions[3]["stop"])
        self.assertTrue(decisions[4]["stop"])
        self.assertEqual(decisions[-1]["best_epoch"], 1)
        self.assertEqual(len(decisions), 5)
        reset = select_epochs([score(0), score(.01), score(.009), score(.02)])
        self.assertEqual(reset[-1]["no_improvement"], 0)
        self.assertEqual(reset[-1]["best_epoch"], 3)

    def test_two_seeds_regressing_in_one_model_make_epoch_ineligible(self):
        candidate = score(.04)
        for row in candidate["individual"]:
            if row["model"] == "qwen_14b" and row["seed"] in (7, 17):
                row.update(median=-.02, repeats=[-.0205, -.02, -.0195])
        result = select_epochs([score(0), candidate])[-1]
        self.assertFalse(result["eligible"])
        self.assertEqual(result["best_epoch"], 0)
        self.assertEqual(result["no_improvement"], 1)
        self.assertFalse(result["stop"])
        result = select_epochs([score(i * .01) for i in range(11)])[-1]
        self.assertTrue(result["stop"])
        self.assertEqual(result["best_epoch"], 10)

    def test_single_trace_cases_keep_repeats_and_reject_missing_or_wrong_hardware(self):
        protocol = {"objective": "throughput", "models": {m: {} for m in MODELS},
                    "validation_trace_ids": [f"v{i}" for i in range(5)], "test_load_multipliers": [.5, .75, 1, 1.25, 1.5],
                    "scope": "replay", "runtime": {"validation_signature": {"cpu_model": "test"}}}
        methods = [{"method": "ppo", "seed": seed, "checkpoint": f"seed_{seed}/ppo.pt"} for seed in SEEDS]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manifest = prepare_comparison(root, root, protocol, methods=methods)
            self.assertEqual(len(manifest["cases"]), 225)
            for case in manifest["cases"]:
                folder = root / "cases" / f"{case['case_id']:03d}"
                folder.mkdir(parents=True)
                traces = [{"trace_id": case["trace_id"], "repeat": i, "requests": 1000, "output_token_throughput": 100 + i} for i in range(3)]
                (folder / "result.json").write_text(json.dumps({**case, "traces": traces, "signature": {"cpu_model": "test"}}))
            _, rows = read_throughput_results(root)
            self.assertEqual(len(rows), 675)
            scores = epoch_scores(rows, rows)
            self.assertAlmostEqual(scores["median"], 0)
            boosted = [{**row, "output_token_throughput": row["output_token_throughput"] * 1.1} for row in rows]
            import math
            self.assertAlmostEqual(epoch_scores(boosted, rows)["median"], math.log(1.1))
            path = root / "cases/000/result.json"
            result = json.loads(path.read_text())
            result["signature"]["cpu_model"] = "different"
            path.write_text(json.dumps(result))
            with self.assertRaisesRegex(ValueError, "hardware"):
                read_throughput_results(root)
            result["signature"]["cpu_model"] = "test"
            result["traces"].pop()
            path.write_text(json.dumps(result))
            with self.assertRaisesRegex(ValueError, "three distinct"):
                read_throughput_results(root)

    def test_test_payload_is_not_read_while_loading_validation(self):
        from dops_serve.placement_evaluation import load_traces
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "workloads.jsonl"
            path.write_text(''.join(json.dumps({"trace_id": "val", "split": "val"}) + '\n' for _ in range(1000)) + 'TEST PAYLOAD MUST NOT BE PARSED\n')
            self.assertEqual(len(load_traces(directory, "val", ["val"])["val"]), 1000)


if __name__ == "__main__":
    unittest.main()
