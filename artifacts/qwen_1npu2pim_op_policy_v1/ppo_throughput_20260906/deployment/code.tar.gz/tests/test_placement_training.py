import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import torch

from dops_serve.placement_policy import PlacementActor
from dops_serve.placement_training import block_returns, cost_weights, ppo_loss, update_ppo


class PlacementTrainingTest(unittest.TestCase):
    def test_segmented_ppo_restores_optimizer_and_rng_like_uninterrupted_training(self):
        from dops_serve.placement_evaluator import PlacementEvaluator
        from dops_serve.placement_policy import policy_inputs
        from dops_serve.placement_training import train_ppo, load_actor, _save
        from dops_serve.replay import PlacementReplay

        repo = Path(__file__).resolve().parents[1]
        backend = os.environ.get("DOPS_BACKEND_ROOT", repo / "artifacts/qwen_1npu2pim_op_policy_v1/backend/DOPS")
        config = json.loads((repo / "configs/op_policy_v1.json").read_text())
        config["models"] = ["qwen_1.8b"]
        records = [{"request_id": "a", "arrival_time": 0, "prompt_len": 128, "max_tokens": 1024, "output_len": 3},
                   {"request_id": "b", "arrival_time": 1, "prompt_len": 256, "max_tokens": 1024, "output_len": 2}]
        protocol = {"backend_config": config, "train_trace_ids": ["tiny"], "training_load_multipliers": [0.5, 1.0],
                    "models": {"qwen_1.8b": {"reference_rps": 1, "slo_s": 1, "reward": {"a_N": 1, "a_T": 1, "lambda_q": 1, "lambda_l": 1}}},
                    "ppo": {"learning_rate": 1e-4, "ppo_epochs": 1, "clip": 0.2, "value_coefficient": 0.5,
                            "entropy_coefficient": 0.001, "max_grad_norm": 1, "rollout_windows": 1, "trace_epochs": 1, "gamma": 1.0, "gae_lambda": 1.0}}
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            evaluator = PlacementEvaluator(backend, root / "backend", "qwen_1.8b", config)
            replay = PlacementReplay(records, evaluator, slo_s=1)
            replay._arrivals()
            inputs = policy_inputs(replay.observation(), evaluator, "prefill")
            torch.manual_seed(7)
            actor = PlacementActor(len(inputs["state"]), len(inputs["nodes"][0][0]))
            checkpoint_path = root / "bc.pt"
            _save(actor, checkpoint_path, stage="BC", seed=7, exclude_model=None)
            with patch("dops_serve.placement_evaluation.load_traces", return_value={"tiny": records}), patch("dops_serve.replay.time.perf_counter", return_value=0.0):
                train_ppo(backend, root, config, checkpoint_path, root / "whole", protocol, trace_epochs=2)
                train_ppo(backend, root, config, checkpoint_path, root / "first", protocol, trace_epochs=1)
                resumed = train_ppo(backend, root, config, root / "first/ppo.pt", root / "second", protocol, trace_epochs=1)
            whole, full = load_actor(root / "whole/ppo.pt")
            segmented, final = load_actor(root / "second/ppo.pt")
            self.assertEqual(full["updates"], final["updates"])
            self.assertEqual(full["completed_traces"], final["completed_traces"])
            self.assertEqual(resumed["continuation"], "exact optimizer/RNG resume")
            for key, value in whole.state_dict().items():
                torch.testing.assert_close(value, segmented.state_dict()[key], rtol=0, atol=0)
            # Changing objectives resets the critic/Adam, then exact resume works
            # within the new objective with a deterministic rotating schedule.
            import copy
            from dops_serve.placement_training import initialize_throughput
            new_protocol = copy.deepcopy(protocol)
            new_protocol["objective"] = "throughput"
            calibration = new_protocol["models"]["qwen_1.8b"]
            del calibration["slo_s"]
            calibration["reward"] = {"a_N": 1, "a_T": 1}
            initialize_throughput(root / "whole/ppo.pt", root / "zero", new_protocol, 7)
            initial, metadata = load_actor(root / "zero/ppo.pt")
            self.assertEqual(metadata["epoch"], 0)
            self.assertEqual(metadata["updates"], 0)
            self.assertEqual(metadata["optimizer_state_dict"]["state"], {})
            self.assertEqual(whole.sequence(inputs, deterministic=True)["program"], initial.sequence(inputs, deterministic=True)["program"])
            self.assertFalse(torch.equal(whole.value_head[0].weight, initial.value_head[0].weight))
            with patch("dops_serve.placement_evaluation.load_traces", return_value={"tiny": records}), patch("dops_serve.replay.time.perf_counter", return_value=0.0):
                train_ppo(backend, root, config, root / "zero/ppo.pt", root / "new-whole", new_protocol, trace_epochs=2)
                train_ppo(backend, root, config, root / "zero/ppo.pt", root / "new-first", new_protocol, trace_epochs=1)
                train_ppo(backend, root, config, root / "new-first/ppo.pt", root / "new-second", new_protocol, trace_epochs=1)
            complete, full = load_actor(root / "new-whole/ppo.pt")
            resumed, final = load_actor(root / "new-second/ppo.pt")
            self.assertEqual(full["completed_traces"], final["completed_traces"])
            self.assertEqual(full["updates"], final["updates"])
            for key, value in complete.state_dict().items():
                torch.testing.assert_close(value, resumed.state_dict()[key], rtol=0, atol=0)

    def test_bc_checkpoint_and_ppo_execute_new_plans_in_real_backend(self):
        from dops_serve.placement_evaluator import PlacementEvaluator
        from dops_serve.placement_policy import LearnedPlacement, policy_inputs
        from dops_serve.placement_training import train_bc, load_actor
        from dops_serve.replay import PlacementReplay

        repo = Path(__file__).resolve().parents[1]
        backend = os.environ.get("DOPS_BACKEND_ROOT", repo / "artifacts/qwen_1npu2pim_op_policy_v1/backend/DOPS")
        config = json.loads((repo / "configs/op_policy_v1.json").read_text())
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            evaluator = PlacementEvaluator(backend, root / "backend", "qwen_1.8b", config)
            rows = [{"request_id": "a", "arrival_time": 0.0, "prompt_len": 128, "max_tokens": 1024, "output_len": 3}]
            replay = PlacementReplay(rows, evaluator, slo_s=1, decode_window=1)
            replay._arrivals()
            placements = [{"placement_id": str(action), "block_actions": evaluator.compiler.uniform(action)} for action in (0, 1)]
            (root / "placements.jsonl").write_text("".join(json.dumps(row) + "\n" for row in placements))
            files = []
            for split, prompt in (("train", 128), ("val", 256)):
                observation = replay.observation()
                observation["waiting"][0]["prompt_len"] = prompt
                path = root / f"{split}.jsonl"
                path.write_text(json.dumps({"inputs": policy_inputs(observation, evaluator, "prefill"), "candidates": [{"placement_id": "0", "cost_s": 1.0}, {"placement_id": "1", "cost_s": 2.0}]}) + "\n")
                files.append({"path": str(path), "split": split})
            (root / "reevaluation_summary.json").write_text(json.dumps({"complete": True, "files": files}))
            result = train_bc(root, root / "learning", epochs=2)
            actor, checkpoint = load_actor(result["checkpoint"])
            self.assertEqual(checkpoint["stage"], "BC")
            selector = LearnedPlacement(actor, evaluator, deterministic=False)
            windows = []
            while not replay.done:
                result = replay.run_window(selector, {"a_N": 1, "a_T": 1, "lambda_q": 1, "lambda_l": 1})
                windows.append({**selector.last, "reward": result["reward"], "terminal": result["terminal"]})
            self.assertEqual(len(replay.completed), 1)
            self.assertEqual(sum(w["output_tokens"] for w in replay.windows), 3)
            optimizer = torch.optim.Adam(actor.parameters(), lr=1e-4)
            result = update_ppo(actor, optimizer, windows, 0, {"ppo_epochs": 1, "clip": 0.2, "value_coefficient": 0.5, "entropy_coefficient": 0.001, "max_grad_norm": 1})
            self.assertTrue(torch.isfinite(torch.tensor(result["loss"])))

    def test_cost_weights_preserve_nonwinners_and_ignore_cost_units(self):
        weights = cost_weights([1, 2, 4], 1)
        self.assertGreater(weights[0], weights[1])
        self.assertGreater(weights[1], weights[2])
        self.assertGreater(weights[2], 0)
        torch.testing.assert_close(weights, cost_weights([1000, 2000, 4000], 1))
        torch.testing.assert_close(cost_weights([2, 2], 1), torch.tensor([0.5, 0.5], dtype=torch.float64))

    def test_undiscounted_feedback_and_truncation_bootstrap(self):
        windows = [{"values": [0] * 3, "reward": 2, "terminal": False}, {"values": [0] * 5, "reward": 4, "terminal": False}]
        self.assertEqual(block_returns(windows, 10), [[16] * 3, [14] * 5])
        windows[-1]["terminal"] = True
        self.assertEqual(block_returns(windows, 10), [[6] * 3, [4] * 5])

    def test_probability_ratio_is_for_the_whole_block(self):
        # Two independent nodes each become 1.5x more probable: block ratio=2.25.
        new = torch.log(torch.tensor([0.3 * 0.6]))
        old = torch.log(torch.tensor([0.2 * 0.4]))
        loss, log = ppo_loss(new, old, torch.tensor([1.0]), torch.zeros(1), torch.zeros(1), torch.zeros(1), clip=0.2, value_coefficient=0, entropy_coefficient=0)
        self.assertAlmostEqual(float(loss), -1.2, places=6)
        self.assertEqual(log["clip_fraction"], 1.0)

    def test_ppo_reconstructs_prefixes_and_updates_parameters(self):
        torch.set_num_threads(1)
        torch.manual_seed(7)
        actor = PlacementActor(3, 2)
        inputs = {phase: {"state": [1, 2, 3], "nodes": [[[1, 0], [0, 1]], [[0.5, 1]]], "masks": [[[True, True], [True, False]], [[True, True]]]} for phase in ("prefill", "decode")}
        windows = []
        for reward in (1.0, -0.5):
            with torch.no_grad():
                result = actor.pair(inputs)
            windows.append({"inputs": inputs, "programs": result["programs"], "log_probs": result["log_probs"].tolist(), "values": result["values"].tolist(), "reward": reward, "terminal": False})
        optimizer = torch.optim.Adam(actor.parameters(), lr=1e-4)
        before = actor.actor_head[-1].weight.detach().clone()
        result = update_ppo(actor, optimizer, windows, 0.25, {"ppo_epochs": 2, "clip": 0.2, "value_coefficient": 0.5, "entropy_coefficient": 0.001, "max_grad_norm": 1})
        self.assertTrue(torch.isfinite(torch.tensor(list(result.values()))).all())
        self.assertFalse(torch.equal(before, actor.actor_head[-1].weight))


if __name__ == "__main__":
    unittest.main()
