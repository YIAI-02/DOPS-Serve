"""The login-side coordinator must respect validation lag and stopping decisions."""
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


class SubmissionTest(unittest.TestCase):
    def run_fixture(self, completed_epoch, stop):
        script = Path(__file__).resolve().parents[1] / "scripts/advance_throughput.py"
        spec = importlib.util.spec_from_file_location("advance_throughput", script)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "experiment"
            root.mkdir()
            protocol = {"runtime": {"sample_threads": 1, "update_threads": 1, "update_device": "cpu"}}
            (root / "training_protocol.json").write_text(json.dumps(protocol))
            names = ["prepare", "profile-cpu-1", "profile-cpu-2", "profile-cpu-4", "freeze", "initialize", "prepare-val-0", "val-0", "references", "reference-summary", "summary-0"]
            for epoch in range(1, completed_epoch + 1):
                names += [f"train-{epoch}", f"prepare-val-{epoch}", f"val-{epoch}", f"summary-{epoch}"]
                folder = root / "validation" / f"epoch_{epoch:03d}"
                folder.mkdir(parents=True)
                (folder / "decision.json").write_text(json.dumps({"stop": stop and epoch == completed_epoch, "epoch": epoch, "best_epoch": 0, "no_improvement": epoch}))
            jobs = {name: {"job_id": str(i + 1), "complete": True, "array": None} for i, name in enumerate(names)}
            if stop:
                jobs[f"train-{completed_epoch + 1}"] = {"job_id": "999", "array": "0-2"}
            else:
                # Epoch 1 is trained and its validation manifest is ready, but
                # its validation has not completed; only epoch 2 may run ahead.
                jobs["train-1"] = {"job_id": "700", "complete": True, "array": "0-2"}
                jobs["prepare-val-1"] = {"job_id": "701", "complete": True, "array": None}
            for folder in [root / "validation/references", *[root / "validation" / f"epoch_{e:03d}" for e in range(max(1, completed_epoch) + 1)]]:
                folder.mkdir(parents=True, exist_ok=True)
                (folder / "comparison_cases.json").write_text(json.dumps({"cases": [{}] * 225}))
            (root / "jobs.json").write_text(json.dumps({"jobs": jobs, "eval_concurrency": 48}))
            calls = []

            def output(command, **kwargs):
                calls.append(command)
                if command[0] == "squeue":
                    return "999_0\n" if stop else ""
                if command[0] == "sbatch":
                    return str(1000 + len(calls))
                raise AssertionError(f"unexpected accounting check: {command}")

            with patch("sys.argv", [str(script), "--repo-root", directory, "--experiment-dir", str(root)]), patch.object(module.subprocess, "check_output", side_effect=output), patch.object(module.subprocess, "run") as cancel:
                module.main()
            final = json.loads((root / "jobs.json").read_text())
            if stop:
                cancel.assert_called_once_with(["scancel", "999"], check=True)
                self.assertTrue(final["jobs"][f"train-{completed_epoch + 1}"]["excluded_from_selection"])
                self.assertIn("prepare-test", final["jobs"])
                self.assertNotIn(f"train-{completed_epoch + 2}", final["jobs"])
            else:
                self.assertIn("val-1", final["jobs"])
                self.assertIn("train-2", final["jobs"])
                self.assertNotIn("train-3", final["jobs"])
                cancel.assert_not_called()

    def test_validation_limits_training_to_one_epoch_ahead(self):
        self.run_fixture(0, False)

    def test_plateau_cancels_only_own_speculative_epoch_before_test(self):
        self.run_fixture(3, True)


if __name__ == "__main__":
    unittest.main()
