#!/usr/bin/env python3
"""Run on the login node: inspect experiment state and submit/cancel its Slurm jobs.

No replay, Torch, plotting or model loading occurs here. Invoke again after a
state change (the Codex heartbeat calls this through the existing SSH master).
"""
import argparse
import fcntl
import json
import os
import subprocess
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", default="/lustre/home/2501111916/workspace/DOPS-Serve")
    parser.add_argument("--experiment-dir")
    parser.add_argument("--eval-concurrency", type=int)
    parser.add_argument("--gpu-partition")
    parser.add_argument("--gpu-gres")
    args = parser.parse_args()
    repo = Path(args.repo_root)
    artifact = repo / "artifacts/qwen_1npu2pim_op_policy_v1"
    root = Path(args.experiment_dir) if args.experiment_dir else artifact / "ppo_throughput_20260906"
    root.mkdir(parents=True, exist_ok=True)
    with (root / "submission.lock").open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        ledger_path = root / "jobs.json"
        ledger = json.loads(ledger_path.read_text()) if ledger_path.exists() else {"jobs": {}, "eval_concurrency": args.eval_concurrency or 48}
        jobs = ledger["jobs"]
        active = subprocess.check_output(["squeue", "-h", "-u", os.environ["USER"], "-o", "%i"], universal_newlines=True).splitlines()
        active_ids = {job.strip().split("_")[0] for job in active}
        submitted_now = set()

        def save():
            ledger_path.write_text(json.dumps(ledger, indent=2) + "\n")

        if args.eval_concurrency is not None:
            ledger["eval_concurrency"] = args.eval_concurrency
            save()

        if args.gpu_partition and args.gpu_gres:
            ledger["gpu"] = {"partition": args.gpu_partition, "gres": args.gpu_gres}
            save()

        def submit(name, stage, *, array=None, cpus=1, extra=None, partition="C064M0256G", gres=None):
            if name in jobs:
                return
            environment = {**os.environ, "REPO_ROOT": str(repo), "ARTIFACT_DIR": str(artifact), "EXPERIMENT_DIR": str(root), "STAGE": stage, **(extra or {})}
            command = ["sbatch", "--parsable", f"--job-name=opt-{name}", f"--partition={partition}", f"--cpus-per-task={cpus}"]
            if array:
                command.append(f"--array={array}")
            if gres:
                command.append(f"--gres={gres}")
            command.append(str(repo / "slurm/op_policy_throughput.sbatch"))
            job = subprocess.check_output(command, env=environment, universal_newlines=True).strip().split(";")[0]
            jobs[name] = {"job_id": job, "stage": stage, "array": array, "cpus": cpus, "partition": partition, "gres": gres, "environment": extra or {}}
            submitted_now.add(name)
            save()
            print(json.dumps({"submitted": name, "job_id": job}), flush=True)

        def done(name):
            if name not in jobs:
                return False
            if name in submitted_now:
                return False
            if jobs[name].get("complete"):
                return True
            job = jobs[name]["job_id"]
            if job in active_ids:
                return False
            lines = subprocess.check_output(["sacct", "-X", "-n", "-P", "-j", job, "--format=JobIDRaw,State,ExitCode"], universal_newlines=True).splitlines()
            records = [line.split("|")[:3] for line in lines if line.strip()]
            if not records:
                return False
            if jobs[name]["array"]:
                bounds = jobs[name]["array"].split("%")[0].split("-")
                expected = int(bounds[1]) - int(bounds[0]) + 1
                if len(records) < expected:
                    return False
            if any(state != "COMPLETED" or code != "0:0" for _, state, code in records):
                raise RuntimeError(f"{name} needs inspection; no retry or later progression: {records}")
            jobs[name]["complete"] = True
            save()
            return True

        def evaluate(name, folder):
            manifest = json.loads((folder / "comparison_cases.json").read_text())
            submit(name, "evaluate", array=f"0-{len(manifest['cases'])-1}%{ledger['eval_concurrency']}", cpus=runtime["sample_threads"], extra={"COMPARISON_DIR": str(folder)})

        submit("prepare", "prepare", cpus=4)
        prepared = done("prepare")
        # This file is written only after the tests and metadata checks pass.
        # Resource probes may overlap the independent fixed-plan timing check.
        if not prepared and not (root / "data_preflight.json").exists():
            return
        for threads in (1, 2, 4):
            submit(f"profile-cpu-{threads}", "profile", cpus=threads, extra={"PROBE_THREADS": str(threads)})
        # A GPU probe is opt-in after inspecting the account's real GPU resources.
        # Without a declared allocation, CPU remains the measured configuration.
        if "gpu" in ledger:
            gpu = ledger["gpu"]
            submit("profile-gpu", "profile", partition=gpu["partition"], gres=gpu["gres"], extra={"UPDATE_DEVICE": "cuda", "PROBE_THREADS": "1"})
        probes = [f"profile-cpu-{threads}" for threads in (1, 2, 4)]
        if "gpu" in ledger:
            probes.append("profile-gpu")
        if not prepared or not all(done(name) for name in probes):
            return
        submit("freeze", "freeze")
        if not done("freeze"):
            return
        protocol = json.loads((root / "training_protocol.json").read_text())
        runtime = protocol["runtime"]
        if runtime["update_device"] != "cpu":
            # GPU host CPU may differ; validation must use that same CPU family.
            # Require an explicit verified match before any formal experiment.
            cpu_profile = json.loads((root / "probe/cpu_1/profile.json").read_text())
            if runtime["validation_signature"]["cpu_model"] != cpu_profile["signature"]["cpu_model"]:
                raise RuntimeError("GPU host CPU differs from validation partition; freeze a matched allocation before training")
        submit("initialize", "initialize", array="0-2")
        if not done("initialize"):
            return
        submit("prepare-val-0", "prepare-validation", extra={"EPOCH": "0"})
        if not done("prepare-val-0"):
            return
        evaluate("val-0", root / "validation/epoch_000")
        evaluate("references", root / "validation/references")

        def train(epoch):
            extra = {"EPOCH": str(epoch), "UPDATE_DEVICE": runtime["update_device"]}
            gpu = ledger.get("gpu", {}) if runtime["update_device"] == "cuda" else {}
            submit(f"train-{epoch}", "train", array="0-2", cpus=max(runtime["sample_threads"], runtime["update_threads"]),
                   partition=gpu.get("partition", "C064M0256G"), gres=gpu.get("gres"), extra=extra)

        # Epoch 0 validation and the first training epoch are independent.
        train(1)
        if done("references") and done("val-0"):
            submit("reference-summary", "references")
        if not done("val-0"):
            return
        submit("summary-0", "summarize", extra={"EPOCH": "0"})
        if not done("summary-0"):
            return
        for epoch in range(1, 11):
            if not done(f"train-{epoch}"):
                train(epoch)
                return
            submit(f"prepare-val-{epoch}", "prepare-validation", extra={"EPOCH": str(epoch)})
            if not done(f"prepare-val-{epoch}"):
                return
            evaluate(f"val-{epoch}", root / "validation" / f"epoch_{epoch:03d}")
            # At most one speculative epoch, never cross phase caps before validation.
            if epoch not in (5, 10):
                train(epoch + 1)
            if not done(f"val-{epoch}"):
                return
            submit(f"summary-{epoch}", "summarize", extra={"EPOCH": str(epoch)})
            if not done(f"summary-{epoch}"):
                return
            state = json.loads((root / "validation" / f"epoch_{epoch:03d}" / "decision.json").read_text())
            if state["stop"]:
                for name, job in jobs.items():
                    if name == f"train-{epoch + 1}" and not job.get("cancelled"):
                        subprocess.run(["scancel", job["job_id"]], check=True)
                        job["cancelled"] = True
                        job["excluded_from_selection"] = True
                        save()
                if not done("references") or not done("reference-summary"):
                    return
                submit("prepare-test", "prepare-test")
                if not done("prepare-test"):
                    return
                evaluate("test", root / "test")
                if not done("test"):
                    return
                submit("test-summary", "test-summary")
                if done("test-summary"):
                    ledger["complete"] = True
                    save()
                    print(json.dumps({"complete": True, "best_epoch": state["best_epoch"], "stop_epoch": epoch}), flush=True)
                return
            if epoch == 5:
                if state["no_improvement"] >= 3:
                    raise RuntimeError("epoch 6 requires a new eligible best within the latest three epochs")
                train(6)
        raise RuntimeError("epoch 10 must terminate the experiment")


if __name__ == "__main__":
    main()
