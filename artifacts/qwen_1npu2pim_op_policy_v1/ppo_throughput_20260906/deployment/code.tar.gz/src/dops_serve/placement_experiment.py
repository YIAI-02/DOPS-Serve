"""The approved throughput continuation experiment, using existing PPO/replay files."""
from __future__ import annotations

import argparse
import copy
import json
import resource
import statistics
import time
from pathlib import Path

from .placement_evaluation import choose_trace_ids, load_traces, scaled_trace, host_signature


def prepare(artifact_dir, root):
    source, root = Path(artifact_dir), Path(root)
    old = json.loads((source / "training_protocol.json").read_text())
    metadata = [json.loads(line) for line in (source / "workload_windows.jsonl").open()]
    previous_end = -1
    for row in metadata:
        if row["sorted_eligible_start"] < previous_end or row["sorted_eligible_end_exclusive"] - row["sorted_eligible_start"] != 1000:
            raise ValueError("trace metadata overlaps or has an incomplete window")
        previous_end = row["sorted_eligible_end_exclusive"]
    protocol = {"objective": "throughput", "status": "probe; training pool/runtime not yet frozen", "scope": old["scope"],
                "backend_config": old["backend_config"], "ppo": old["ppo"], "source_protocol": str(source / "training_protocol.json"),
                "training_load_multipliers": old["training_load_multipliers"], "test_load_multipliers": old["test_load_multipliers"],
                "models": {model: {"reference_rps": row["reference_rps"], "static": row["static"],
                                   "reward": {key: row["reward"][key] for key in ("a_N", "a_T")}} for model, row in old["models"].items()},
                "train_trace_ids": choose_trace_ids(source, "train", 5), "validation_trace_ids": choose_trace_ids(source, "val", 5),
                "test_trace_ids": choose_trace_ids(source, "test", 5), "test_locked": True,
                "runtime": {"sample_threads": 1, "update_threads": 1, "update_device": "cpu"},
                "selection": {"patience": 3, "first_phase_max_epoch": 5, "max_epoch": 10, "repeats": 3, "seeds": [7, 17, 27]}}
    if not set(old["train_trace_ids"]) <= set(protocol["train_trace_ids"]) or not set(old["validation_trace_ids"]) <= set(protocol["validation_trace_ids"]):
        raise ValueError("time-spread selection did not preserve original traces")
    root.mkdir(parents=True, exist_ok=True)
    (root / "probe_protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    result = {"trace_counts": {split: sum(row["split"] == split for row in metadata) for split in ("train", "val", "test")},
              "validation_trace_ids": protocol["validation_trace_ids"], "test_trace_ids": protocol["test_trace_ids"],
              "test_request_contents_read": False}
    (root / "data_preflight.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def profile(backend_root, artifact_dir, root, threads, device, windows=8):
    import torch
    from .placement_evaluator import PlacementEvaluator
    from .placement_policy import LearnedPlacement, policy_inputs
    from .placement_training import initialize_throughput, load_actor, run_update
    from .replay import PlacementReplay

    root = Path(root)
    protocol = json.loads((root / "probe_protocol.json").read_text())
    runtime = {"sample_threads": threads, "update_threads": threads, "update_device": device}
    protocol["runtime"] = runtime
    folder = root / "probe" / f"{device}_{threads}"
    folder.mkdir(parents=True, exist_ok=True)
    initialize_throughput(Path(artifact_dir) / "continuation_20260906/seed_7/ppo.pt", folder / "initial", protocol, 7)
    io_started = time.perf_counter()
    trace = protocol["train_trace_ids"][0]
    records = load_traces(artifact_dir, "train", [trace])[trace]
    io_s = time.perf_counter() - io_started
    logs = []
    for repeat in range(2):
        for model in protocol["models"]:
            torch.set_num_threads(threads)
            actor, checkpoint = load_actor(folder / "initial/ppo.pt")
            torch.set_rng_state(checkpoint["torch_rng_state"])
            evaluator = PlacementEvaluator(backend_root, folder / "backend", model, protocol["backend_config"])
            calibration = protocol["models"][model]
            replay = PlacementReplay(scaled_trace(records, calibration["reference_rps"]), evaluator)
            selector = LearnedPlacement(actor, evaluator, deterministic=False)
            optimizer = torch.optim.Adam(actor.parameters(), lr=protocol["ppo"]["learning_rate"])
            started, cpu_started = time.perf_counter(), time.process_time()
            sample_s = update_s = 0.0
            while not replay.done and len(replay.windows) < windows:
                sample_started = time.perf_counter()
                rollout = []
                for _ in range(protocol["ppo"]["rollout_windows"]):
                    result = replay.run_window(selector, calibration["reward"])
                    rollout.append({**copy.deepcopy(selector.last), "reward": result["reward"], "terminal": result["terminal"]})
                    if replay.done:
                        break
                bootstrap = 0.0
                if not replay.done:
                    current = evaluator.compiler.project(replay.plans["prefill"]["device_by_node"])
                    inputs = policy_inputs(replay.observation(), evaluator, "prefill", current)
                    with torch.no_grad():
                        bootstrap = float(actor.sequence(inputs, deterministic=True)["values"][0])
                sample_s += time.perf_counter() - sample_started
                update_s += run_update(actor, optimizer, rollout, bootstrap, protocol["ppo"], runtime)["update_wall_s"]
            total_s = time.perf_counter() - started
            row = {"model": model, "repeat": repeat, "windows": len(replay.windows), "completed_requests": len(replay.completed),
                   "sample_s": sample_s, "update_s": update_s, "total_s": total_s,
                   "simulator_s": sum(r["host_evaluator_s"] for r in replay.step_results),
                   "decision_s": sum(r["decision_s"] for r in replay.windows),
                   "output_tokens": sum(r["output_tokens"] for r in replay.windows),
                   "full_trace_output_tokens": sum(r["output_len"] for r in records),
                   "cpu_time_s": time.process_time() - cpu_started, "peak_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
            logs.append(row)
            print(json.dumps(row), flush=True)
    result = {"runtime": runtime, "signature": host_signature(threads), "io_s": io_s, "rows": logs,
              "probe_only": True, "gpu_name": torch.cuda.get_device_name() if device == "cuda" else None}
    (folder / "profile.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def freeze(artifact_dir, root):
    root = Path(root)
    profiles = [json.loads((root / "probe" / f"cpu_{threads}" / "profile.json").read_text()) for threads in (1, 2, 4)]
    gpu_path = root / "probe/cuda_1/profile.json"
    if gpu_path.exists():
        profiles.append(json.loads(gpu_path.read_text()))
    # Choose on complete replay+update timing, including transfers; never GPU kernel time alone.
    def cost(item):
        return sum(statistics.median(r["total_s"] / r["output_tokens"] for r in item["rows"] if r["model"] == model) for model in {r["model"] for r in item["rows"]})
    selected = min(profiles, key=cost)
    protocol = json.loads((root / "probe_protocol.json").read_text())
    candidates = {}
    for count in (5, 10, 20):
        traces = load_traces(artifact_dir, "train", choose_trace_ids(artifact_dir, "train", count))
        output_tokens = sum(r["output_len"] for rows in traces.values() for r in rows)
        # Short, cold-prefix measurements are uncertain: use slower repeat and a 30% margin.
        candidates[count] = 1.3 * output_tokens * sum(max(r["total_s"] / r["output_tokens"] for r in selected["rows"] if r["model"] == model) for model in protocol["models"])
    eligible = [count for count, seconds in candidates.items() if seconds <= 14 * 3600]
    count = max(eligible) if eligible else 5
    protocol["train_trace_ids"] = choose_trace_ids(artifact_dir, "train", count)
    protocol["runtime"] = {**selected["runtime"], "validation_signature": selected["signature"]}
    protocol["status"] = "frozen throughput continuation; test locked until validation selection ends"
    protocol["resource_estimate"] = {"candidate_epoch_seconds_per_seed": candidates, "train_trace_count": count,
                                     "method": "slower repeated cold-prefix total seconds/output token, scaled by train-pool output tokens, plus 30% margin; estimate, not guarantee",
                                     "profile_costs": [{"runtime": p["runtime"], "relative_cost": cost(p) / cost(profiles[0])} for p in profiles]}
    (root / "training_protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    return protocol["resource_estimate"]


def prepare_validation(artifact_dir, root, epoch):
    from .placement_comparison import prepare_comparison
    root = Path(root)
    protocol = json.loads((root / "training_protocol.json").read_text())
    methods = [{"method": "ppo", "seed": seed, "epoch": epoch, "checkpoint": str(root / f"seed_{seed}/epoch_{epoch:03d}/ppo.pt")} for seed in (7, 17, 27)]
    result = prepare_comparison(artifact_dir, root / "validation" / f"epoch_{epoch:03d}", protocol, methods=methods)
    if epoch == 0:
        references = [{"method": method, "seed": None, "checkpoint": None} for method in ("static", "bifocal")]
        references += [{"method": "bc", "seed": seed, "checkpoint": str(Path(artifact_dir) / f"learning/seed_{seed}/bc.pt")} for seed in (7, 17, 27)]
        prepare_comparison(artifact_dir, root / "validation/references", protocol, methods=references)
    return {"cases": len(result["cases"])}


def prepare_test(artifact_dir, root):
    from .placement_comparison import prepare_comparison
    root = Path(root)
    state = json.loads((root / "training_state.json").read_text())
    if not state["stop"]:
        raise ValueError("test stays locked until validation selection is final")
    protocol = json.loads((root / "training_protocol.json").read_text())
    best = state["best_epoch"]
    methods = [{"method": method, "seed": None, "checkpoint": None} for method in ("static", "bifocal")]
    methods += [{"method": "bc", "seed": seed, "checkpoint": str(Path(artifact_dir) / f"learning/seed_{seed}/bc.pt")} for seed in (7, 17, 27)]
    methods += [{"method": "ppo_old", "seed": seed, "epoch": 0, "checkpoint": str(root / f"seed_{seed}/epoch_000/ppo.pt")} for seed in (7, 17, 27)]
    if best:
        methods += [{"method": "ppo", "seed": seed, "epoch": best, "checkpoint": str(root / f"seed_{seed}/epoch_{best:03d}/ppo.pt")} for seed in (7, 17, 27)]
    frozen = {"best_epoch": best, "seeds": [7, 17, 27], "validation_stop_epoch": state["epoch"], "test_trace_ids": protocol["test_trace_ids"], "methods": methods}
    (root / "test_selection_frozen.json").write_text(json.dumps(frozen, indent=2) + "\n")
    result = prepare_comparison(artifact_dir, root / "test", protocol, methods=methods, split="test", trace_ids=protocol["test_trace_ids"])
    return {"cases": len(result["cases"]), "best_epoch": best}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("prepare", "profile", "freeze", "initialize", "train", "prepare-validation", "evaluate", "summarize", "references", "prepare-test", "test-summary"))
    for flag in ("backend-root", "artifact-dir", "experiment-dir"):
        parser.add_argument("--" + flag, required=True)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--epoch", type=int, default=0)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--device", default="cpu", choices=("cpu", "cuda"))
    parser.add_argument("--case-id", type=int)
    parser.add_argument("--comparison-dir")
    args = parser.parse_args()
    root, source = Path(args.experiment_dir), Path(args.artifact_dir)
    if args.action == "prepare":
        result = prepare(source, root)
    elif args.action == "profile":
        result = profile(args.backend_root, source, root, args.threads, args.device)
    elif args.action == "freeze":
        result = freeze(source, root)
    elif args.action in ("initialize", "train"):
        from .placement_training import initialize_throughput, train_ppo
        protocol = json.loads((root / "training_protocol.json").read_text())
        if args.action == "initialize":
            result = initialize_throughput(source / f"continuation_20260906/seed_{args.seed}/ppo.pt", root / f"seed_{args.seed}/epoch_000", protocol, args.seed)
        else:
            result = train_ppo(args.backend_root, source, protocol["backend_config"], root / f"seed_{args.seed}/epoch_{args.epoch - 1:03d}/ppo.pt", root / f"seed_{args.seed}/epoch_{args.epoch:03d}", protocol, seed=args.seed, trace_epochs=1)
    elif args.action == "prepare-validation":
        result = prepare_validation(source, root, args.epoch)
    elif args.action == "evaluate":
        from .placement_comparison import evaluate_case
        result = evaluate_case(args.backend_root, source, args.comparison_dir, args.case_id)
    elif args.action == "summarize":
        from .placement_comparison import summarize_throughput
        result = summarize_throughput(root, args.epoch)
    elif args.action == "references":
        from .placement_comparison import summarize_references
        result = summarize_references(root / "validation/references", root / "validation/epoch_000")
    elif args.action == "prepare-test":
        result = prepare_test(source, root)
    else:
        from .placement_comparison import read_throughput_results, summarize_references
        # Reuse the old-PPO subset as the independently measured test reference.
        manifest, _ = read_throughput_results(root / "test")
        reference_dir = root / "test/old_reference"
        reference_dir.mkdir(exist_ok=True)
        manifest["cases"] = [case for case in manifest["cases"] if case["method"] == "ppo_old"]
        (reference_dir / "comparison_cases.json").write_text(json.dumps(manifest, indent=2) + "\n")
        if not (reference_dir / "cases").exists():
            (reference_dir / "cases").symlink_to(root / "test/cases", target_is_directory=True)
        result = summarize_references(root / "test", reference_dir)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
