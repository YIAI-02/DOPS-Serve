"""Paired validation of Static, fixed-order Bifocal, BC and PPO checkpoints."""
from __future__ import annotations

import json
import platform
import statistics
import time
from pathlib import Path

from .placement_evaluation import StaticPlacement, load_traces, replay_metrics, scaled_trace
from .placement_evaluator import PlacementEvaluator
from .replay import PlacementReplay


def prepare_comparison(artifact_dir, output_dir, protocol, *, continued_dir=None, methods=None, split="val", trace_ids=None):
    source, destination = Path(artifact_dir), Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    if protocol.get("objective") == "throughput":
        traces = trace_ids if trace_ids is not None else protocol["validation_trace_ids"]
        cases = [{"case_id": i, **method, "model": model, "load_multiplier": load, "trace_id": trace}
                 for i, (method, model, load, trace) in enumerate(
                     (method, model, load, trace) for method in methods for model in protocol["models"]
                     for load in protocol["test_load_multipliers"] for trace in traces)]
        result = {"split": split, "trace_ids": traces, "protocol": protocol, "cases": cases,
                  "repeats": 3, "scope": protocol["scope"], "checkpoint_compatibility": "same backend, feature ABI and deterministic CPU selector; rewards may differ"}
        (destination / "comparison_cases.json").write_text(json.dumps(result, indent=2) + "\n")
        return result
    methods = [{"method": method, "seed": None, "checkpoint": None} for method in ("static", "bifocal")]
    for method in ("bc", "ppo"):
        methods.extend({"method": method, "seed": seed, "checkpoint": str(source / "learning" / f"seed_{seed}" / f"{method}.pt")} for seed in (7, 17, 27))
    if continued_dir:
        methods.extend({"method": "ppo_continued", "seed": seed, "checkpoint": str(Path(continued_dir) / f"seed_{seed}" / "ppo.pt")} for seed in (7, 17, 27))
    cases = []
    for method in methods:
        for model in protocol["models"]:
            for load in protocol["test_load_multipliers"]:
                cases.append({"case_id": len(cases), **method, "model": model, "load_multiplier": load})
    result = {
        "split": "val", "purpose": "compare pilot and continuation on fixed validation data; no test-based training decisions",
        "trace_ids": protocol["validation_trace_ids"], "protocol": protocol, "cases": cases,
        "scope": protocol["scope"], "slo_violation_limit": 0.01,
        "bifocal": "pinned backend score and configuration; fixed topological order; NPU or node's fixed PIM; no actual remaining output length",
        "learned_decoding": "deterministic argmax; identical to deployment selection",
        "decision_overhead": "measured selector, feature, compile and search wall time is charged to simulated serving time",
    }
    (destination / "comparison_cases.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def evaluate_case(backend_root, artifact_dir, output_dir, case_id):
    import torch
    from .placement_policy import LearnedPlacement
    from .placement_training import load_actor
    from .placement_evaluation import host_signature

    destination = Path(output_dir)
    manifest = json.loads((destination / "comparison_cases.json").read_text())
    case = manifest["cases"][case_id]
    protocol = manifest["protocol"]
    throughput = protocol.get("objective") == "throughput"
    runtime = protocol.get("runtime", {})
    torch.set_num_threads(runtime.get("sample_threads", 1))
    signature = host_signature(runtime.get("sample_threads", 1))
    if throughput and signature != runtime["validation_signature"]:
        raise ValueError(f"validation host/runtime changed: {signature}")
    config, model = protocol["backend_config"], case["model"]
    calibration = protocol["models"][model]
    trace_ids = [case["trace_id"]] if throughput else manifest["trace_ids"]
    traces = load_traces(artifact_dir, manifest["split"], trace_ids)
    folder = destination / "cases" / f"{case_id:03d}"
    folder.mkdir(parents=True, exist_ok=True)
    actor, checkpoint = None, None
    if case["checkpoint"]:
        actor, checkpoint = load_actor(case["checkpoint"])
        expected_stage = "BC" if case["method"] == "bc" else "PPO"
        if checkpoint["stage"] != expected_stage or checkpoint["seed"] != case["seed"] or checkpoint["exclude_model"] is not None:
            raise ValueError("comparison checkpoint differs from the declared method, seed or model split")
        if expected_stage == "PPO":
            compatible = checkpoint["protocol"]["backend_config"] == config if throughput else checkpoint["protocol"] == protocol
            if not compatible:
                raise ValueError("PPO checkpoint and comparison backend/protocol differ")
            if "epoch" in case and checkpoint["epoch"] != case["epoch"]:
                raise ValueError("comparison checkpoint has the wrong epoch")
        actor.eval()
    results, baseline_config = [], None
    for trace_id, rows in traces.items():
        for repeat in range(manifest.get("repeats", 1)):
            evaluator = PlacementEvaluator(backend_root, folder / "backend", model, config)
            records = scaled_trace(rows, calibration["reference_rps"] * case["load_multiplier"])
            replay = PlacementReplay(records, evaluator, slo_s=calibration.get("slo_s"), max_batch=config["max_batch"], decode_window=config["decode_window"])
            if case["method"] == "static":
                selector = StaticPlacement(evaluator, calibration["static"]["programs"])
            elif case["method"] == "bifocal":
                from .placement_baselines import FixedOrderBifocalPlacement
                from scheduler import scheduler_bifocal as bifocal
                baseline_config = {key: getattr(bifocal, key) for key in (
                    "SCHED_JOINT_LK_ENABLE", "SCHED_JOINT_LK_H", "SCHED_JOINT_LK_GAMMA",
                    "SCHED_JOINT_LK_CONSIST_LAMBDA", "SCHED_JOINT_LK_PLAN_HINT_MAX", "SCHED_WEIGHT_BIAS_ETA",
                )}
                selector = FixedOrderBifocalPlacement(evaluator, lambda: replay.snapshot, max_batch=config["max_batch"], seed=7)
            else:
                selector = LearnedPlacement(actor, evaluator, deterministic=True)
            started = time.perf_counter()
            while not replay.done:
                replay.run_window(selector, calibration["reward"])
                if len(replay.windows) % 50 == 0:
                    print(json.dumps({"case_id": case_id, "trace_id": trace_id, "repeat": repeat, "windows": len(replay.windows), "completed": len(replay.completed)}), flush=True)
            metrics = replay_metrics(replay, time.perf_counter() - started)
            result = {"trace_id": trace_id, **metrics, "cumulative_reward": sum(w["reward"] for w in replay.windows), "windows": len(replay.windows)}
            if throughput:
                result["repeat"] = repeat
            results.append(result)
            prefix = f"{trace_id}_repeat_{repeat}" if throughput else trace_id
            (folder / f"{prefix}_windows.jsonl").write_text("".join(json.dumps(w) + "\n" for w in replay.windows))
            (folder / f"{prefix}_requests.jsonl").write_text("".join(json.dumps(r) + "\n" for r in replay.request_metrics()))
    result = {
        **case, "split": manifest["split"], "scope": manifest["scope"], "host": platform.node(), "signature": signature,
        "reference_rps": calibration["reference_rps"], "traces": results, "baseline_config": baseline_config,
        "checkpoint_metadata": {k: checkpoint[k] for k in ("stage", "seed", "epoch", "updates", "continuation") if checkpoint is not None and k in checkpoint},
    }
    if not throughput:
        result["slo_s"] = calibration["slo_s"]
    (folder / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def summarize_comparison(output_dir):
    destination = Path(output_dir)
    manifest = json.loads((destination / "comparison_cases.json").read_text())
    rows, missing = [], []
    for case in manifest["cases"]:
        path = destination / "cases" / f"{case['case_id']:03d}" / "result.json"
        if not path.exists():
            missing.append(case["case_id"])
            continue
        result = json.loads(path.read_text())
        if any(result[key] != case[key] for key in case) or [r["trace_id"] for r in result["traces"]] != manifest["trace_ids"]:
            raise ValueError(f"case {case['case_id']} does not match the comparison manifest")
        if any(r["requests"] != 1000 for r in result["traces"]):
            raise ValueError("comparison requires full 1000-request traces")
        rows.extend({**case, **trace} for trace in result["traces"])
    paired = []
    index = {(r["method"], r["seed"], r["model"], r["load_multiplier"], r["trace_id"]): r for r in rows}
    for row in rows:
        if row["method"] not in ("ppo", "ppo_continued"):
            continue
        reference = "bc" if row["method"] == "ppo" else "ppo"
        before = index.get((reference, row["seed"], row["model"], row["load_multiplier"], row["trace_id"]))
        if before is None:
            continue
        paired.append({
            **{k: row[k] for k in ("model", "seed", "load_multiplier", "trace_id")},
            "before": reference, "after": row["method"],
            "throughput_change_pct": 100 * (row["output_token_throughput"] / before["output_token_throughput"] - 1),
            "p99_change_pct": 100 * (row["e2e_p99_s"] / before["e2e_p99_s"] - 1),
            "violation_change_pp": 100 * (row["e2e_violation_rate"] - before["e2e_violation_rate"]),
            "before_slo_pass": before["e2e_violation_rate"] <= 0.01,
            "after_slo_pass": row["e2e_violation_rate"] <= 0.01,
        })
    capacity = []
    groups = sorted({(r["method"], r["seed"] or 0, r["model"]) for r in rows})
    for method, seed, model in groups:
        group = [r for r in rows if (r["method"], r["seed"] or 0, r["model"]) == (method, seed, model)]
        loads = []
        for load in manifest["protocol"]["test_load_multipliers"]:
            subset = [r for r in group if r["load_multiplier"] == load]
            if len(subset) != len(manifest["trace_ids"]):
                continue
            violation = sum(r["e2e_violations"] for r in subset) / sum(r["requests"] for r in subset)
            throughput = sum(r["output_tokens"] for r in subset) / sum(r["duration_s"] for r in subset)
            loads.append({"load_multiplier": load, "violation_rate": violation, "throughput": throughput})
        feasible = [r for r in loads if r["violation_rate"] <= 0.01]
        best = max(feasible, key=lambda r: r["throughput"]) if feasible else None
        capacity.append({"method": method, "seed": seed or None, "model": model, "complete_load_scan": len(loads) == 5, "slo_feasible_best": best, "loads": loads})
    result = {"complete": not missing, "missing_cases": missing, "completed_cases": len(manifest["cases"]) - len(missing),
              "split": manifest["split"], "scope": manifest["scope"], "capacity": capacity, "paired": paired}
    (destination / "comparison_summary.json").write_text(json.dumps(result, indent=2) + "\n")
    lines = ["# 固定验证集上的策略比较", "", f"完成 {result['completed_cases']}/{len(manifest['cases'])} 个条件。范围：{manifest['scope']}。", "",
             "吞吐只在已扫描负载中选择，E2E 违约率须不超过 1%；无达标档位记为未达标。测试集未使用。", "",
             "| 方法 | 种子 | 模型 | 五档完整 | 达标最高 token/s | 对应负载 |", "|---|---:|---|---|---:|---:|"]
    for row in capacity:
        best = row["slo_feasible_best"]
        lines.append(f"| {row['method']} | {row['seed'] or '固定'} | {row['model']} | {row['complete_load_scan']} | {best['throughput']:.4f} | {best['load_multiplier']} |" if best else f"| {row['method']} | {row['seed'] or '固定'} | {row['model']} | {row['complete_load_scan']} | 未达标 | — |")
    lines.extend(["", "## 同条件配对变化", "", "正吞吐变化表示更快；负 p99/违约率变化表示改善。随机种子全部保留，不按验证结果挑种子。", "",
                  "| 比较 | 模型 | 配对数 | 吞吐变化均值 | p99 变化均值 | 违约率变化（百分点） |", "|---|---|---:|---:|---:|---:|"])
    for after in ("ppo", "ppo_continued"):
        for model in manifest["protocol"]["models"]:
            group = [r for r in paired if r["after"] == after and r["model"] == model]
            if group:
                means = [statistics.fmean(r[key] for r in group) for key in ("throughput_change_pct", "p99_change_pct", "violation_change_pp")]
                lines.append(f"| {group[0]['before']} → {after} | {model} | {len(group)} | {means[0]:+.2f}% | {means[1]:+.2f}% | {means[2]:+.2f} |")
    if missing:
        lines.extend(["", "仍有未完成条件，以上为部分结果，不能用于宣布整体优胜。"])
    lines.extend(["", "单条验证 trace 的比较不足以证明泛化或稳定收益。续训是否改善应同时检查各模型、各种子的达标吞吐及配对延迟，不能仅看训练 reward。"])
    (destination / "comparison_summary.md").write_text("\n".join(lines) + "\n")
    return result


def read_throughput_results(directory):
    """Read only complete, three-repeat, hardware-matched comparison cases."""
    directory = Path(directory)
    manifest = json.loads((directory / "comparison_cases.json").read_text())
    rows = []
    for case in manifest["cases"]:
        path = directory / "cases" / f"{case['case_id']:03d}" / "result.json"
        result = json.loads(path.read_text())
        if any(result[key] != value for key, value in case.items()):
            raise ValueError(f"case {case['case_id']} does not match its manifest")
        if result["signature"] != manifest["protocol"]["runtime"]["validation_signature"]:
            raise ValueError("comparison hardware/runtime differs from the frozen protocol")
        if [(r["trace_id"], r["repeat"]) for r in result["traces"]] != [(case["trace_id"], i) for i in range(3)]:
            raise ValueError("comparison requires three distinct complete repeats")
        for trace in result["traces"]:
            if trace["requests"] != 1000:
                raise ValueError("comparison requires all 1000 requests")
            rows.append({**case, **trace})
    return manifest, rows


def epoch_scores(rows, reference_rows):
    import math
    from collections import defaultdict
    reference = defaultdict(list)
    for row in reference_rows:
        reference[(row["model"], row["seed"], row["trace_id"], row["load_multiplier"])].append(row["output_token_throughput"])
    groups = defaultdict(list)
    for row in rows:
        key = (row["model"], row["seed"], row["trace_id"], row["load_multiplier"])
        groups[(row["model"], row["seed"], row["repeat"])].append(math.log(row["output_token_throughput"] / statistics.median(reference[key])))
    individual = []
    for model, seed in sorted({(r["model"], r["seed"]) for r in rows}):
        scores = [statistics.fmean(groups[(model, seed, repeat)]) for repeat in range(3)]
        individual.append({"model": model, "seed": seed, "repeats": scores, "median": statistics.median(scores), "range": max(scores) - min(scores)})
    scores = [statistics.fmean(row["repeats"][repeat] for row in individual) for repeat in range(3)]
    return {"repeats": scores, "median": statistics.median(scores), "range": max(scores) - min(scores), "individual": individual}


def select_epochs(scores):
    """Process complete epochs in order; a rebound below historical best is not progress."""
    best, stale, decisions = 0, 0, []
    zero = {(r["model"], r["seed"]): r for r in scores[0]["individual"]}
    for epoch, candidate in enumerate(scores):
        if epoch == 0:
            decisions.append({"epoch": 0, "best_epoch": 0, "no_improvement": 0, "eligible": True, "improved": False, "stop": False, "regressions": []})
            continue
        regressions = []
        for row in candidate["individual"]:
            baseline = zero[(row["model"], row["seed"])]
            if baseline["median"] - row["median"] > max(baseline["range"], row["range"]):
                regressions.append({"model": row["model"], "seed": row["seed"]})
        eligible = all(sum(r["model"] == model for r in regressions) < 2 for model in {r["model"] for r in candidate["individual"]})
        improved = eligible and candidate["median"] - scores[best]["median"] > max(candidate["range"], scores[best]["range"])
        if improved:
            best, stale = epoch, 0
        else:
            stale += 1
        stop = stale >= 3 or epoch >= 10
        decisions.append({"epoch": epoch, "best_epoch": best, "no_improvement": stale, "eligible": eligible,
                          "improved": improved, "stop": stop, "regressions": regressions,
                          "reason": "three epochs without a new eligible best" if stale >= 3 else "epoch 10 cap" if epoch >= 10 else "continue"})
        if stop:
            break
    return decisions


def summarize_throughput(experiment_dir, epoch):
    import csv
    import math
    root = Path(experiment_dir)
    protocol = json.loads((root / "training_protocol.json").read_text())
    _, reference = read_throughput_results(root / "validation/epoch_000")
    scores, all_rows = [], []
    for number in range(epoch + 1):
        _, rows = read_throughput_results(root / "validation" / f"epoch_{number:03d}")
        scores.append(epoch_scores(rows, reference))
        all_rows.extend({**row, "epoch": number} for row in rows)
    decisions = select_epochs(scores)
    if len(decisions) != epoch + 1:
        raise ValueError("an earlier epoch already stopped training; later checkpoints cannot enter selection")
    result = {**decisions[-1], "scores": scores, "decisions": decisions, "complete": True, "scope": protocol["scope"]}
    out = root / "validation" / f"epoch_{epoch:03d}"
    (out / "decision.json").write_text(json.dumps(result, indent=2) + "\n")
    (root / "training_state.json").write_text(json.dumps(result, indent=2) + "\n")
    progress = []
    zero_scores = {(r["model"], r["seed"]): r["median"] for r in scores[0]["individual"]}
    for number, score in enumerate(scores):
        for item in score["individual"]:
            zero_center = zero_scores[(item["model"], item["seed"])]
            row = {"epoch": number, "model": item["model"], "seed": item["seed"],
                   "relative_throughput_pct": 100 * math.exp(item["median"] - zero_center),
                   "repeat_min_pct": 100 * math.exp(min(item["repeats"]) - zero_center), "repeat_max_pct": 100 * math.exp(max(item["repeats"]) - zero_center),
                   "best_epoch": decisions[number]["best_epoch"], "no_improvement": decisions[number]["no_improvement"]}
            checkpoint_summary = root / f"seed_{item['seed']}" / f"epoch_{number:03d}" / "ppo_summary.json"
            training = json.loads(checkpoint_summary.read_text()) if number else {"updates": 0, "completed_traces": [], "training_wall_s": 0}
            row.update(updates=training["updates"], cumulative_requests=sum(t["completed"] for t in training["completed_traces"]),
                       cumulative_windows=sum(t["windows"] for t in training["completed_traces"]), training_hours=training["training_wall_s"] / 3600)
            progress.append(row)
    with (root / "training_progress.csv").open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(progress[0])); writer.writeheader(); writer.writerows(progress)
    from .placement_figures import plot_epochs
    plot_epochs(root, all_rows, reference, decisions)
    lines = ["# PPO 吞吐目标训练进度", "", f"已完成新目标 epoch {epoch} 的全部固定验证；最佳为 epoch {result['best_epoch']}，连续无有效新最佳 {result['no_improvement']} 轮。",
             f"状态：{'停止并保留最佳模型' if result['stop'] else '继续训练'}。本结果是调度回放。", "",
             "每个条件均完整回放 1000 个请求、独立复测 3 次。波动带表示三次观测范围，不是统计置信区间。", "",
             "| 模型 | 种子 | 相对 epoch 0 吞吐 | 复测范围 | 累计请求 | 训练小时 |", "|---|---:|---:|---:|---:|---:|"]
    for row in progress[-9:]:
        lines.append(f"| {row['model']} | {row['seed']} | {row['relative_throughput_pct']:.3f}% | {row['repeat_min_pct']:.3f}–{row['repeat_max_pct']:.3f}% | {row['cumulative_requests']} | {row['training_hours']:.2f} |")
    if result["regressions"]:
        lines += ["", "观察到超出复测波动的单种子退步：" + ", ".join(f"{r['model']}/seed {r['seed']}" for r in result["regressions"]) + "。"]
    (root / "training_report.md").write_text("\n".join(lines) + "\n")
    return result


def summarize_references(output_dir, reference_dir):
    import csv
    import math
    from collections import defaultdict
    manifest, rows = read_throughput_results(output_dir)
    _, reference = read_throughput_results(reference_dir)
    baseline = defaultdict(list)
    for row in reference:
        baseline[(row["model"], row["seed"], row["trace_id"], row["load_multiplier"])].append(row)
    summaries = []
    for method, seed, model in sorted({(r["method"], r["seed"] or 0, r["model"]) for r in rows}):
        group = [r for r in rows if (r["method"], r["seed"] or 0, r["model"]) == (method, seed, model)]
        paired = defaultdict(list)
        for row in group:
            # Fixed baselines have no training seed: pair with all three old PPO seeds.
            for ref_seed in ([seed] if seed else [7, 17, 27]):
                before = baseline[(model, ref_seed, row["trace_id"], row["load_multiplier"])]
                paired[row["repeat"]].append(math.log(row["output_token_throughput"] / statistics.median(r["output_token_throughput"] for r in before)))
        scores = [math.exp(statistics.fmean(paired[i])) * 100 for i in range(3)]
        summaries.append({"method": method, "seed": seed or None, "model": model, "throughput_relative_to_old_ppo_pct": statistics.median(scores),
                          "repeat_min_pct": min(scores), "repeat_max_pct": max(scores), "replays": len(group),
                          "throughput_geomean": math.exp(statistics.fmean(math.log(r["output_token_throughput"]) for r in group)),
                          "paired_condition_p99_geomean_s": math.exp(statistics.fmean(math.log(r["e2e_p99_s"]) for r in group)),
                          "decision_fraction_mean": statistics.fmean(r["decision_fraction"] for r in group)})
    root = Path(output_dir)
    (root / "comparison_summary.json").write_text(json.dumps({"complete": True, "split": manifest["split"], "summaries": summaries}, indent=2) + "\n")
    with (root / "comparison_summary.csv").open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summaries[0])); writer.writeheader(); writer.writerows(summaries)
    lines = ["# 同条件吞吐比较", "", f"数据划分：{manifest['split']}。同条件旧 PPO 第 2 轮为 100%；固定方法与三个旧种子等权配对。",
             "p99 几何均值描述条件之间的汇总，不是合并全部请求后的 p99。", "", "| 方法 | 种子 | 模型 | 相对旧 PPO 吞吐 | 复测范围 |", "|---|---:|---|---:|---:|"]
    for row in summaries:
        lines.append(f"| {row['method']} | {row['seed'] or '固定'} | {row['model']} | {row['throughput_relative_to_old_ppo_pct']:.3f}% | {row['repeat_min_pct']:.3f}–{row['repeat_max_pct']:.3f}% |")
    (root / "comparison_summary.md").write_text("\n".join(lines) + "\n")
    return {"complete": True, "summaries": summaries}
