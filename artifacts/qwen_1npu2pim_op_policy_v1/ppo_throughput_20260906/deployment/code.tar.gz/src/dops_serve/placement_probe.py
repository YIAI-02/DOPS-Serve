"""Measure the single fixed-order scheduler change against its original implementation."""
import argparse
import inspect
import json
import textwrap
from pathlib import Path
from time import perf_counter
from unittest.mock import patch

from .placement_evaluation import StaticPlacement, load_traces, scaled_trace
from .placement_evaluator import PlacementEvaluator
from .replay import PlacementReplay


def profile_scheduler(backend_root, artifact_dir, root):
    root = Path(root)
    protocol = json.loads((root / "probe_protocol.json").read_text())
    trace = protocol["train_trace_ids"][0]
    rows = load_traces(artifact_dir, "train", [trace])[trace][:32]
    results = []
    for model, calibration in protocol["models"].items():
        evaluator = PlacementEvaluator(backend_root, root / "probe/backend", model, protocol["backend_config"])
        cls = next(cls for cls in type(evaluator.initial.scheduler).__mro__ if "schedule_with_plan" in cls.__dict__)
        optimized = cls.schedule_with_plan
        source = textwrap.dedent(inspect.getsource(optimized))
        original_source = source.replace("order_nodes = set(order_iter)\n    if len(order_nodes)", "if len(set(order_iter))").replace("nid not in order_nodes]", "nid not in set(order_iter)]")
        if original_source == source or "order_nodes" in original_source:
            raise ValueError("scheduler probe requires the exact order-set-only patch")
        namespace = {}
        exec(compile(original_source, "<original schedule_with_plan>", "exec"), optimized.__globals__, namespace)
        original = namespace["schedule_with_plan"]
        output, timings = {}, {"original": [], "optimized": []}
        try:
            for repeat in range(2):
                # Reverse order on the second repeat to reduce cache/order bias.
                for name in (("original", "optimized") if repeat == 0 else ("optimized", "original")):
                    cls.schedule_with_plan = original if name == "original" else optimized
                    replay = PlacementReplay(scaled_trace(rows, calibration["reference_rps"]), evaluator)
                    selector = StaticPlacement(evaluator, calibration["static"]["programs"])
                    started = perf_counter()
                    with patch("dops_serve.replay.time.perf_counter", return_value=0.0):
                        while not replay.done:
                            replay.run_window(selector, calibration["reward"])
                    timings[name].append(perf_counter() - started)
                    evidence = {"requests": replay.request_metrics(), "steps": replay.step_results, "now": replay.snapshot.now,
                                "kv": replay.snapshot.kv_written_tokens, "reserved": replay.snapshot.kv_reserved_tokens}
                    if output and evidence != output:
                        raise ValueError("order-set optimization changed fixed-plan or KV replay results")
                    output = evidence
        finally:
            cls.schedule_with_plan = optimized
        result = {"model": model, "requests": len(rows), "identical_replay_and_kv": True, "wall_s": timings,
                  "speedup": sum(timings["original"]) / sum(timings["optimized"])}
        results.append(result)
        print(json.dumps(result), flush=True)
    (root / "probe/scheduler_profile.json").write_text(json.dumps(results, indent=2) + "\n")
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    for flag in ("backend-root", "artifact-dir", "experiment-dir"):
        parser.add_argument("--" + flag, required=True)
    args = parser.parse_args()
    profile_scheduler(args.backend_root, args.artifact_dir, args.experiment_dir)
