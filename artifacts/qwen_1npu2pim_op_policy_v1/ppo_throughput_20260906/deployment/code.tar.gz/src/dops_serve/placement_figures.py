"""Traceable epoch plots: raw CSV, three-repeat ranges, PNG and editable SVG."""
from __future__ import annotations

import csv
import math
import statistics
from collections import defaultdict
from pathlib import Path


def plot_epochs(root, rows, reference, decisions):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    import numpy as np

    destination = Path(root) / "figures"
    destination.mkdir(parents=True, exist_ok=True)
    fields = ["epoch", "model", "seed", "trace_id", "load_multiplier", "repeat", "output_token_throughput", "e2e_p99_s", "decision_total_s", "decision_fraction", "requests", "output_tokens", "duration_s", "host_wall_s"]
    with (destination / "epoch_raw.csv").open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader(); writer.writerows(rows)
    references = defaultdict(list)
    for row in reference:
        references[(row["model"], row["seed"], row["trace_id"], row["load_multiplier"])].append(row)
    aggregated = []
    metrics = [("output_token_throughput", "Throughput relative to epoch 0 (%)", "Higher is better"),
               ("e2e_p99_s", "Paired p99 relative to epoch 0 (%)", "Lower is better; not pooled-request p99"),
               ("decision_total_s", "Decision time relative to epoch 0 (%)", "Lower is better")]
    available_fonts = {font.name for font in font_manager.fontManager.ttflist}
    font = next(name for name in ("Arial", "Helvetica", "DejaVu Sans") if name in available_fonts)
    plt.rcParams.update({"font.family": font, "font.size": 11, "svg.fonttype": "none", "axes.spines.top": False, "axes.spines.right": False})
    models = ("qwen_1.8b", "qwen_7b", "qwen_14b")
    epochs = list(range(len(decisions)))
    for metric, label, direction in metrics:
        fig, axes = plt.subplots(1, 3, figsize=(14.4, 5.6))
        for ax, model in zip(axes, models):
            for seed, color, marker in zip((7, 17, 27), ("#0F4D92", "#B64342", "#42949E"), ("o", "s", "^")):
                points = []
                zero_center = None
                for epoch in epochs:
                    group = [r for r in rows if (r["epoch"], r["model"], r["seed"]) == (epoch, model, seed)]
                    scores = []
                    for repeat in range(3):
                        ratios = []
                        for row in group:
                            if row["repeat"] != repeat:
                                continue
                            before = references[(model, seed, row["trace_id"], row["load_multiplier"])]
                            ratios.append(math.log(row[metric] / statistics.median(r[metric] for r in before)))
                        scores.append(100 * math.exp(statistics.fmean(ratios)))
                    if epoch == 0:
                        zero_center = statistics.median(scores)
                    scores = [100 * value / zero_center for value in scores]
                    median = statistics.median(scores)
                    points.append((median, min(scores), max(scores)))
                    aggregated.append({"metric": metric, "epoch": epoch, "model": model, "seed": seed, "median_pct": median, "min_pct": min(scores), "max_pct": max(scores)})
                values = np.array(points)
                ax.errorbar(epochs, values[:, 0], yerr=[values[:, 0] - values[:, 1], values[:, 2] - values[:, 0]], color=color, marker=marker, label=f"Seed {seed}", linewidth=1.8, capsize=3)
            ax.axhline(100, color="#777777", linestyle="--", linewidth=0.8)
            ax.axvline(decisions[-1]["best_epoch"], color="#555555", linestyle=":", linewidth=1.1)
            ax.set_title(model.replace("qwen_", "Qwen-").replace("b", "B"))
            ax.set_xlabel("New-objective epoch")
            ax.set_xticks(epochs)
            ax.grid(axis="y", alpha=0.2)
        axes[0].set_ylabel(label)
        axes[1].legend(loc="upper center", bbox_to_anchor=(0.5, -0.19), ncol=3, frameon=False)
        fig.suptitle(f"{direction} | Best epoch {decisions[-1]['best_epoch']} | No new best: {decisions[-1]['no_improvement']}/3", fontsize=13)
        fig.text(0.5, 0.015, "Fixed validation traces; median and min/max of 3 repeats. Timing/scheduling replay, not real-model inference.", ha="center", fontsize=10)
        fig.tight_layout(rect=(0.01, 0.065, 0.99, 0.94))
        for extension in ("png", "svg"):
            fig.savefig(destination / f"epoch_{metric}.{extension}", dpi=300)
        plt.close(fig)
    with (destination / "epoch_aggregated.csv").open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(aggregated[0])); writer.writeheader(); writer.writerows(aggregated)
