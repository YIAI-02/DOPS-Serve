from __future__ import annotations

import csv
import json
from collections import Counter
from pathlib import Path
from typing import Any


def import_op_policy_burstgpt(
    input_path: str | Path,
    artifact_dir: str | Path,
    requests_per_trace: int = 1000,
) -> dict[str, Any]:
    """Chronological 70/15/15 source splits, shared by every model/load variant."""
    eligible = []
    excluded: Counter = Counter()
    with Path(input_path).open(encoding="utf-8-sig", newline="") as handle:
        for index, row in enumerate(csv.DictReader(handle)):
            if row["Model"] != "ChatGPT" or row["Log Type"] != "API log":
                excluded["not_chatgpt_api"] += 1
                continue
            prompt, output = int(row["Request tokens"]), int(row["Response tokens"])
            if not 128 <= prompt <= 2048:
                excluded["prompt_out_of_range"] += 1
                continue
            if not 1 <= output <= 1024:
                excluded["output_out_of_range"] += 1
                continue
            eligible.append((float(row["Timestamp"]), index, prompt, output))
    eligible.sort()
    boundaries = (0, int(len(eligible) * 0.70), int(len(eligible) * 0.85), len(eligible))
    destination = Path(artifact_dir)
    destination.mkdir(parents=True, exist_ok=True)
    split_summary = {}
    with (destination / "workloads.jsonl").open("w") as records, (destination / "workload_windows.jsonl").open("w") as windows:
        for split, first, last in zip(("train", "val", "test"), boundaries, boundaries[1:]):
            complete = (last - first) // requests_per_trace
            split_summary[split] = {"eligible_requests": last - first, "traces": complete, "discarded_tail": (last - first) % requests_per_trace}
            if complete == 0:
                raise ValueError(f"{split} has no complete {requests_per_trace}-request trace")
            for window in range(complete):
                start = first + window * requests_per_trace
                selected = eligible[start:start + requests_per_trace]
                trace_id = f"burstgpt_{split}_{window:06d}"
                origin = selected[0][0]
                windows.write(json.dumps({
                    "trace_id": trace_id, "split": split,
                    "sorted_eligible_start": start, "sorted_eligible_end_exclusive": start + requests_per_trace,
                    "source_time_start": origin, "source_time_end": selected[-1][0],
                    "source_rows": [item[1] for item in selected],
                }) + "\n")
                for timestamp, index, prompt, output in selected:
                    records.write(json.dumps({
                        "trace_id": trace_id, "source_window_id": trace_id,
                        "split": split, "family": "burstgpt", "request_id": f"burstgpt_row_{index}",
                        "source_row": index, "source_timestamp": timestamp,
                        "arrival_time": timestamp - origin, "prompt_len": prompt,
                        "max_tokens": 1024, "output_len": output,
                    }) + "\n")
    result = {
        "source": str(Path(input_path).resolve()), "eligible_requests": len(eligible),
        "excluded": dict(excluded), "splits": split_summary,
        "requests_per_trace": requests_per_trace, "arrival_scaling": "unscaled; calibrate on train/validation",
        "variants": "model and load variants inherit source_window_id and split",
    }
    (destination / "workload_manifest.json").write_text(json.dumps(result, indent=2) + "\n")
    return result
