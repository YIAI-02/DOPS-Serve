#!/bin/bash
set -euo pipefail
PPO_ROOT=/lustre/home/2501111916/workspace/DOPS-Serve/artifacts/burstgpt_ppo_20260916
# 用户确认提交前报告后才创建 formal_budget.json；本脚本不代替确认。
test -f "$PPO_ROOT/formal_budget.json"
test -f "$PPO_ROOT/hpc_cpu_check_passed.json"
test -f "$PPO_ROOT/worker_check_cuda_passed.json"
mkdir -p "$PPO_ROOT/logs"
sbatch --parsable --account=hpc2006191081 --qos=high --partition="${1:-GPU40G}" \
    --job-name=burst-ppo --array=0-8%3 --nodes=1 --ntasks=1 --cpus-per-task=16 --gres=gpu:1 \
    --time="${2:-3-00:00:00}" --output="$PPO_ROOT/logs/train_%A_%a.out" \
    --error="$PPO_ROOT/logs/train_%A_%a.err" "$PPO_ROOT/code/slurm/run_ppo.sh" train
